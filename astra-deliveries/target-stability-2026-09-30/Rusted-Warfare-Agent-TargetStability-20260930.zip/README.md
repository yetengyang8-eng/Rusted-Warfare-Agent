# Target Stability 交付

分支：astra/target-stability-20260930
本地提交：439dd36c6ccd3bb898ecad7bb83473982e497d11
基线：795146a；包含先前 Recon 集成提交 109f414，然后是本轮目标资格修复。
GitHub push 因无写凭据未完成；这不是已更新远端分支的声明。未安装用户桌面。

rw-agent-bootstrap.jar 是本轮原生测试使用的完整源码构建。
SHA256：165bd3b2207f96cee41a2dc3c8e25c36ce3ae799dd46a268304fe8dd65acf245
contentDigest：cfaeeab48d1b7e3d2eb238a87f3aeb92de6a1be6e0661fc4ff839ca99a9f712e

源码：在干净的 main 795146a 工作分支使用 git am from-main-795146a.patch（内含两个提交）。
若已经具有同样的 Recon 集成源码，可审查 target-stability-only.patch，它只有本轮增量；不要再应用完整包。
source-changes/ 提供变更后文件便于审查。两个提交的补丁已在独立 index 中顺序应用，最终 tree 与 HEAD 完全相同。

核心结果：桌面固定输入的 E2 决策重放，#1026 的目标进军意图旧 106 / 新 0；UNKNOWN 保留。
新的 5x 原生 headless 局跑满 1801.024 游戏秒，有效 PARTIAL/ONGOING；三只 lightSub 自然触发抑制，失联后没有再收到进军意图。
完整分段矩阵 20 Java / 15 Python，271 Python PASS、2 Windows 专用用例在 Linux SKIP。见交接中失败与恢复执行说明。

raw-evidence.zip 同时包含新旧 E2 重放、完整/恢复测试日志、有效原生局和 64 MiB 报告上限失败尝试。
原始桌面输入沿用仓库 evidence/astra-recon-desktop-acceptance-2026-09-29/desktop-raw-reports-2runs.zip，不重复打包。
未附游戏资源包；使用仓库已提供的 headless-engine-1.15.zip 和 prepare 工具。
