# Recon Execution 交付包（2026-09-29）

基线提交：4853dae2bcdcbe0be9fe23cc54edc57345e69856
实现提交：825c08b5a63ee385a313559480a613f84c4eff08
分支：astra/recon-execution-20260929（本地已提交；远端 push 缺少写入凭据，未上传 GitHub）

本包含可测试的 rw-agent-bootstrap.jar、准确构建清单、git format-patch、修改后的源码文件、交接和 E2 证据。

此 JAR 是继承冻结原生桥接的 client overlay，未做原生/headless/Windows 对局；不是已部署候选或竞技增益证明。
SHA256：feb7ad39cb137bda1ef105f6d449bbf1c5875bd9132c0b91790165a824a68f81
contentDigest：1985cb52b52aafb468845898c33b4419b8368f200b4475494cf09796b62a676f

代码接入：在基线提交的干净分支使用 git am recon-execution-20260929.patch。补丁已在临时索引中校验可应用，生成的树与实现提交完全相同。也可查看 source-changes/ 中的各个修改文件。

测试入口与部署要求见 HANDOFF_Astra_ReconExecution_2026-09-29.md。原生测试应在兼容 1.15 独立副本中退出旧进程后使用同一新 JAR 启动游戏和 Match；保留原 KBv0 以便回退。不要在当前活动对局替换文件或只更换客户端。

验收：128 项相关 Python 测试通过，32 项 Java 契约检查通过；四个旧版失效复现用例在候选通过。详细边界、初始失败及最终测试见 evidence/summary.json 与相应日志，模拟原始证据在 evidence/raw-fixtures.zip，全部为 E2。

上一轮 public-relay patch 仅吸收 build.bat 资源与 test.sh 缺项；reap 等其余修改不在本包内。
