# 铁锈战争 Agent 离线报告汇总

结果由事件核对。INVALID 表示报告不完整或计数异常，即使原始 outcome 为 PASS 也不计入通过。

| 报告 | 版本 | 任务 | 判定 | 现实秒数 | 指令 | 观察 | 新矿 | 新厂 | 新坦克 | 建矿时完成坦克 |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| run-20261001T043906-137221/episode-001/rw-agent-reports/battle-1790829567385-37b24a7d.jsonl | 0.07-alpha1 | battle | PASS | 91.434 | 95 | 155 | 2 | 0 | 0 | 0 |
| run-20261001T043906-137221/episode-001/rw-agent-reports/bootstrap-1790829548418-3dbb299d.jsonl | 0.07-alpha1 | bootstrap | PASS | 0.059 | 0 | 2 | 0 | 0 | 0 | 0 |
| run-20261001T043906-137221/episode-001/rw-agent-reports/development-1790829554671-ac154849.jsonl | 0.07-alpha1 | development | PASS | 12.704 | 7 | 27 | 1 | 0 | 6 | 1 |
| run-20261001T043906-137221/episode-001/rw-agent-reports/economy-1790829548781-1292c518.jsonl | 0.07-alpha1 | economy | PASS | 5.884 | 2 | 14 | 0 | 1 | 1 | 0 |

现实耗时从首个有效事件到最后一个有效事件计算，不是游戏内时间。建矿出兵重叠仅指日志观察区间：同一矿的 extractor_started 到 extractor_completed 之间出现 tank_completed；不等于性能或胜率证明。

| 对战报告 | 原生结算 | 对战游戏秒数 | 新观察战斗单位 | 己方损失 | 已确认进攻指令 | 工厂升级 |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| run-20261001T043906-137221/episode-001/rw-agent-reports/battle-1790829567385-37b24a7d.jsonl | VICTORY | 438.848 | 22 | 20 | 47 | 1 |

对战 PASS 只表示已观察到原生结算。VICTORY 才是获胜；DEFEAT 是完整败局；PARTIAL 是仍在进行的限时样本。

## run-20261001T043906-137221/episode-001/rw-agent-reports/battle-1790829567385-37b24a7d.jsonl

**阶段** battle；**扩张** —

Native result screen: VICTORY

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "Native result screen: VICTORY",
  "phase": "battle",
  "matchOutcome": "VICTORY",
  "commands": 95,
  "observations": 155,
  "ownLosses": 20,
  "newCombatUnits": 22,
  "attackOrders": 47,
  "attackOrdersConfirmed": 47,
  "retreatOrders": 11,
  "upgradesCompleted": 1,
  "completedMines": 2,
  "newMines": 2,
  "mineTarget": 3,
  "minesBeyondFloor": 0,
  "expansionRefusals": 1,
  "expansionBlocked": 40,
  "completedFactories": 0,
  "newFactories": 0,
  "landFactoryTarget": 2,
  "factoryBlocks": 0,
  "builderTarget": 1,
  "builderRecoveries": 1,
  "builderOrders": 1,
  "battleGameTimeMs": 438848,
  "gameSecondsPerWallSecond": 4.8,
  "noProgressWindowMs": 20000,
  "noProgressCooldownMs": 30000,
  "targetNoProgressTriggers": 0,
  "targetRetries": 0,
  "targetSuppressionsStarted": 0,
  "targetSuppressionsReleased": 0,
  "targetSuppressedSelections": 0,
  "targetSuppressionsAtEnd": 0,
  "targetSwitches": 29,
  "effectiveDecisionIntervalGameMs": 3104,
  "noProgressAttentionGapMs": 9312,
  "maxObservedGameTimeJump": 3248,
  "observationCount": 155,
  "spendTotal": 22300,
  "spendByCategory": {
    "FACTORY_UPGRADE": {
      "orders": 1,
      "cost": 2000
    },
    "UNIT_PRODUCTION": {
      "orders": 23,
      "cost": 18400
    },
    "NEW_MINE": {
      "orders": 2,
      "cost": 1400
    },
    "BUILDER_RECOVERY": {
      "orders": 1,
      "cost": 500
    }
  },
  "measuredIncomePerGameSecond": 51.64,
  "investmentIntentions": 0,
  "investmentCompletions": 0,
  "investmentCancellations": 0,
  "investmentReserveAtEnd": 0,
  "investmentPendingAtEnd": false,
  "finalUrgency": "EMERGENCY",
  "reconEnabled": true,
  "reconTasksCreated": 4,
  "reconOrdersQueued": 3,
  "reconOrdersObserved": 3,
  "reconMovesCompletedBetweenSamples": 0,
  "frontierTasksSatisfiedByTeamVision": 0,
  "reconResolvedAfterObservedMove": 1,
  "reconReacquired": 4,
  "reconSitesCleared": 0,
  "reconBlocked": 0,
  "reconTaskPendingAtEnd": false,
  "reconFrontierEnabled": true,
  "frontierTasksCreated": 0,
  "frontierTasksRefreshed": 0,
  "frontierTasksAdvanced": 0,
  "frontierTasksBlocked": 0,
  "frontierTasksPreempted": 0,
  "expendableTransfers": 0,
  "expendableScoutsAtEnd": 0,
  "factoryTargetIncreases": 0,
  "factoryTargetIncreaseBlocks": 0,
  "landFactoryTargetAtEnd": 2,
  "factoryTargetCommittedAtEnd": false,
  "landFactoryTargetMax": 5,
  "factorySaturationPct": 81.25,
  "factorySaturationMinPct": 80,
  "economyBaseIncome": 26.9,
  "economyIncomePerMine": 12.07,
  "economyModelSource": "MEASURED_4_MATCHES_2_SPEEDS_T1_R2_0.999_T2_T3_ESTIMATED_FROM_FROZEN_GENERATION_RATIOS",
  "minesReadyAtEnd": 3,
  "productionConsumptionPerGameSecond": 42.7,
  "sustainableSurplusPerGameSecond": 20.4,
  "strategy": {
    "enabled": true,
    "armyTarget": 35,
    "activeTarget": 24,
    "reserveTarget": 11,
    "hardSafetyCap": 128,
    "builderTarget": 1,
    "capabilityNeedsAtEnd": 0,
    "needsResolvedByLegalEvidence": 0,
    "investmentOrders": 0,
    "mineUpgradesObserved": 0,
    "constructionCompletionsObserved": 0,
    "capabilityReservesStarted": 0,
    "capabilityReservesReleased": 0,
    "capabilityReserveAtEnd": 0.0
  }
}
```

## run-20261001T043906-137221/episode-001/rw-agent-reports/bootstrap-1790829548418-3dbb299d.jsonl

**阶段** ready_preflight；**扩张** —

Completed own builder available; fresh preflight permits Match

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "Completed own builder available; fresh preflight permits Match",
  "phase": "ready_preflight",
  "bootstrapMode": "EXISTING_BUILDER",
  "commands": 0,
  "automaticProductionCommands": 0,
  "observations": 2,
  "queueObserved": false,
  "producerId": -1,
  "builderId": 4,
  "resolvedBuilderType": "builder",
  "completionEvidence": "EXISTING_READY_BUILDER",
  "gameBudgetSeconds": 180,
  "wallBudgetSeconds": 120
}
```

## run-20261001T043906-137221/episode-001/rw-agent-reports/development-1790829554671-ac154849.jsonl

**阶段** tank_observe；**扩张** LIMIT_REACHED

Tank target completed; mines 1/1; expansion LIMIT_REACHED; all task units alive

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "Tank target completed; mines 1/1; expansion LIMIT_REACHED; all task units alive",
  "phase": "tank_observe",
  "commands": 7,
  "observations": 27,
  "completedMines": 1,
  "completedTanks": 6,
  "expansionStatus": "LIMIT_REACHED",
  "scoutMoves": 0,
  "scoutArrivals": 0,
  "scoutBlocked": 0,
  "scoutedMines": 0,
  "scoutRetreats": 0,
  "escortsAssigned": 0,
  "escortsConfirmed": 0,
  "newlyExploredTiles": 0
}
```

## run-20261001T043906-137221/episode-001/rw-agent-reports/economy-1790829548781-1292c518.jsonl

**阶段** tank_1_produce；**扩张** —

New landFactory completed; its queue was observed active then empty; one new own tank appeared nearby

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "New landFactory completed; its queue was observed active then empty; one new own tank appeared nearby",
  "phase": "tank_1_produce",
  "commands": 2,
  "observations": 14,
  "completedBuildings": 1,
  "completedTanks": 1
}
```
