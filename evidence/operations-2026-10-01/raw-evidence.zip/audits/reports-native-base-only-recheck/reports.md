# 铁锈战争 Agent 离线报告汇总

结果由事件核对。INVALID 表示报告不完整或计数异常，即使原始 outcome 为 PASS 也不计入通过。

| 报告 | 版本 | 任务 | 判定 | 现实秒数 | 指令 | 观察 | 新矿 | 新厂 | 新坦克 | 建矿时完成坦克 |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| run-20261001T044255-8d37b3/episode-001/rw-agent-reports/battle-1790829799739-15226af4.jsonl | 0.07-alpha1 | battle | PARTIAL | 250.229 | 361 | 418 | 8 | 2 | 0 | 0 |
| run-20261001T044255-8d37b3/episode-001/rw-agent-reports/bootstrap-1790829778732-06388cf4.jsonl | 0.07-alpha1 | bootstrap | PASS | 2.243 | 1 | 7 | 0 | 0 | 0 | 0 |
| run-20261001T044255-8d37b3/episode-001/rw-agent-reports/development-1790829787118-e6bbdc87.jsonl | 0.07-alpha1 | development | PASS | 12.608 | 7 | 27 | 1 | 0 | 6 | 2 |
| run-20261001T044255-8d37b3/episode-001/rw-agent-reports/economy-1790829781280-e5aeb2c3.jsonl | 0.07-alpha1 | economy | PASS | 5.826 | 2 | 14 | 0 | 1 | 1 | 0 |

现实耗时从首个有效事件到最后一个有效事件计算，不是游戏内时间。建矿出兵重叠仅指日志观察区间：同一矿的 extractor_started 到 extractor_completed 之间出现 tank_completed；不等于性能或胜率证明。

| 对战报告 | 原生结算 | 对战游戏秒数 | 新观察战斗单位 | 己方损失 | 已确认进攻指令 | 工厂升级 |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| run-20261001T044255-8d37b3/episode-001/rw-agent-reports/battle-1790829799739-15226af4.jsonl | ONGOING | 1201.104 | 80 | 22 | 168 | 3 |

对战 PASS 只表示已观察到原生结算。VICTORY 才是获胜；DEFEAT 是完整败局；PARTIAL 是仍在进行的限时样本。

## run-20261001T044255-8d37b3/episode-001/rw-agent-reports/battle-1790829799739-15226af4.jsonl

**阶段** battle；**扩张** —

Game-time budget reached without native result

原始 summary

```json
{
  "outcome": "PARTIAL",
  "reason": "Game-time budget reached without native result",
  "phase": "battle",
  "matchOutcome": "ONGOING",
  "commands": 361,
  "observations": 418,
  "ownLosses": 22,
  "newCombatUnits": 80,
  "attackOrders": 170,
  "attackOrdersConfirmed": 168,
  "retreatOrders": 6,
  "upgradesCompleted": 3,
  "completedMines": 8,
  "newMines": 8,
  "mineTarget": 3,
  "minesBeyondFloor": 6,
  "expansionRefusals": 56,
  "expansionBlocked": 65,
  "completedFactories": 2,
  "newFactories": 2,
  "landFactoryTarget": 3,
  "factoryBlocks": 4,
  "builderTarget": 1,
  "builderRecoveries": 0,
  "builderOrders": 0,
  "battleGameTimeMs": 1201104,
  "gameSecondsPerWallSecond": 4.8,
  "noProgressWindowMs": 20000,
  "noProgressCooldownMs": 30000,
  "targetNoProgressTriggers": 7,
  "targetRetries": 5,
  "targetSuppressionsStarted": 1,
  "targetSuppressionsReleased": 0,
  "targetSuppressedSelections": 0,
  "targetSuppressionsAtEnd": 1,
  "targetSwitches": 35,
  "effectiveDecisionIntervalGameMs": 3264,
  "noProgressAttentionGapMs": 9792,
  "maxObservedGameTimeJump": 3488,
  "observationCount": 418,
  "spendTotal": 84500,
  "spendByCategory": {
    "FACTORY_UPGRADE": {
      "orders": 3,
      "cost": 6000
    },
    "UNIT_PRODUCTION": {
      "orders": 78,
      "cost": 57700
    },
    "NEW_MINE": {
      "orders": 8,
      "cost": 5600
    },
    "NEW_FACTORY": {
      "orders": 2,
      "cost": 1400
    },
    "STRATEGIC_CAPABILITY": {
      "orders": 3,
      "cost": 7500
    },
    "STRATEGIC_CONSTRUCTION": {
      "orders": 3,
      "cost": 2100
    },
    "MINE_UPGRADE": {
      "orders": 3,
      "cost": 4200
    }
  },
  "measuredIncomePerGameSecond": 104.36,
  "investmentIntentions": 9,
  "investmentCompletions": 5,
  "investmentCancellations": 4,
  "investmentReserveAtEnd": 0,
  "investmentPendingAtEnd": false,
  "finalUrgency": "CONTESTED",
  "reconEnabled": true,
  "reconTasksCreated": 29,
  "reconOrdersQueued": 41,
  "reconOrdersObserved": 4,
  "reconMovesCompletedBetweenSamples": 37,
  "frontierTasksSatisfiedByTeamVision": 19,
  "reconResolvedAfterObservedMove": 2,
  "reconReacquired": 2,
  "reconSitesCleared": 0,
  "reconBlocked": 0,
  "reconTaskPendingAtEnd": false,
  "reconFrontierEnabled": true,
  "frontierTasksCreated": 27,
  "frontierTasksRefreshed": 0,
  "frontierTasksAdvanced": 2,
  "frontierTasksBlocked": 2,
  "frontierTasksPreempted": 4,
  "expendableTransfers": 5,
  "expendableScoutsAtEnd": 1,
  "factoryTargetIncreases": 1,
  "factoryTargetIncreaseBlocks": 2,
  "landFactoryTargetAtEnd": 3,
  "factoryTargetCommittedAtEnd": false,
  "landFactoryTargetMax": 5,
  "factorySaturationPct": 0.0,
  "factorySaturationMinPct": 80,
  "economyBaseIncome": 26.9,
  "economyIncomePerMine": 12.07,
  "economyModelSource": "MEASURED_4_MATCHES_2_SPEEDS_T1_R2_0.999_T2_T3_ESTIMATED_FROM_FROZEN_GENERATION_RATIOS",
  "minesReadyAtEnd": 12,
  "productionConsumptionPerGameSecond": 0.0,
  "sustainableSurplusPerGameSecond": 189.8,
  "strategy": {
    "enabled": true,
    "armyTarget": 64,
    "activeTarget": 52,
    "reserveTarget": 12,
    "hardSafetyCap": 128,
    "builderTarget": 1,
    "capabilityNeedsAtEnd": 5,
    "needsResolvedByLegalEvidence": 0,
    "investmentOrders": 9,
    "mineUpgradesObserved": 3,
    "constructionCompletionsObserved": 3,
    "capabilityReservesStarted": 0,
    "capabilityReservesReleased": 0,
    "capabilityReserveAtEnd": 0.0
  }
}
```

## run-20261001T044255-8d37b3/episode-001/rw-agent-reports/bootstrap-1790829778732-06388cf4.jsonl

**阶段** ready_preflight；**扩张** —

Completed own builder available; fresh preflight permits Match

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "Completed own builder available; fresh preflight permits Match",
  "phase": "ready_preflight",
  "bootstrapMode": "AUTOMATIC_NATIVE_PRODUCTION",
  "commands": 1,
  "automaticProductionCommands": 1,
  "observations": 7,
  "queueObserved": true,
  "producerId": 184,
  "builderId": 202,
  "resolvedBuilderType": "builder",
  "completionEvidence": "NEW_OWN_UNIT_AND_NATIVE_QUEUE_CYCLE",
  "gameBudgetSeconds": 180,
  "wallBudgetSeconds": 120
}
```

## run-20261001T044255-8d37b3/episode-001/rw-agent-reports/development-1790829787118-e6bbdc87.jsonl

**阶段** tank_observe；**扩张** LIMIT_REACHED

Tank target completed; mines 1/1; expansion LIMIT_REACHED; all task units alive

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "Tank target completed; mines 1/1; expansion LIMIT_REACHED; all task units alive",
  "phase": "tank_observe",
  "commands": 7,
  "observations": 27,
  "completedMines": 1,
  "completedTanks": 6,
  "expansionStatus": "LIMIT_REACHED",
  "scoutMoves": 0,
  "scoutArrivals": 0,
  "scoutBlocked": 0,
  "scoutedMines": 0,
  "scoutRetreats": 0,
  "escortsAssigned": 0,
  "escortsConfirmed": 0,
  "newlyExploredTiles": 0
}
```

## run-20261001T044255-8d37b3/episode-001/rw-agent-reports/economy-1790829781280-e5aeb2c3.jsonl

**阶段** tank_1_produce；**扩张** —

New landFactory completed; its queue was observed active then empty; one new own tank appeared nearby

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "New landFactory completed; its queue was observed active then empty; one new own tank appeared nearby",
  "phase": "tank_1_produce",
  "commands": 2,
  "observations": 14,
  "completedBuildings": 1,
  "completedTanks": 1
}
```
