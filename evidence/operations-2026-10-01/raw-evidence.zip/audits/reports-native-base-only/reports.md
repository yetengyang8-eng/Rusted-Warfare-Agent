# 铁锈战争 Agent 离线报告汇总

结果由事件核对。INVALID 表示报告不完整或计数异常，即使原始 outcome 为 PASS 也不计入通过。

| 报告 | 版本 | 任务 | 判定 | 现实秒数 | 指令 | 观察 | 新矿 | 新厂 | 新坦克 | 建矿时完成坦克 |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| run-20261001T043840-d97647/episode-001/rw-agent-reports/battle-1790829544518-c7eff699.jsonl | 0.07-alpha1 | battle | PARTIAL | 250.222 | 347 | 411 | 6 | 2 | 0 | 0 |
| run-20261001T043840-d97647/episode-001/rw-agent-reports/bootstrap-1790829523314-96c211ec.jsonl | 0.07-alpha1 | bootstrap | PASS | 2.262 | 1 | 7 | 0 | 0 | 0 | 0 |
| run-20261001T043840-d97647/episode-001/rw-agent-reports/development-1790829531732-593bb34d.jsonl | 0.07-alpha1 | development | PASS | 12.774 | 7 | 27 | 1 | 0 | 6 | 2 |
| run-20261001T043840-d97647/episode-001/rw-agent-reports/economy-1790829525857-8f783596.jsonl | 0.07-alpha1 | economy | PASS | 5.869 | 2 | 14 | 0 | 1 | 1 | 0 |

现实耗时从首个有效事件到最后一个有效事件计算，不是游戏内时间。建矿出兵重叠仅指日志观察区间：同一矿的 extractor_started 到 extractor_completed 之间出现 tank_completed；不等于性能或胜率证明。

| 对战报告 | 原生结算 | 对战游戏秒数 | 新观察战斗单位 | 己方损失 | 已确认进攻指令 | 工厂升级 |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| run-20261001T043840-d97647/episode-001/rw-agent-reports/battle-1790829544518-c7eff699.jsonl | ONGOING | 1201.04 | 105 | 55 | 144 | 3 |

对战 PASS 只表示已观察到原生结算。VICTORY 才是获胜；DEFEAT 是完整败局；PARTIAL 是仍在进行的限时样本。

## run-20261001T043840-d97647/episode-001/rw-agent-reports/battle-1790829544518-c7eff699.jsonl

**阶段** battle；**扩张** —

Game-time budget reached without native result

原始 summary

```json
{
  "outcome": "PARTIAL",
  "reason": "Game-time budget reached without native result",
  "phase": "battle",
  "matchOutcome": "ONGOING",
  "commands": 347,
  "observations": 411,
  "ownLosses": 55,
  "newCombatUnits": 105,
  "attackOrders": 147,
  "attackOrdersConfirmed": 144,
  "retreatOrders": 14,
  "upgradesCompleted": 3,
  "completedMines": 6,
  "newMines": 6,
  "mineTarget": 3,
  "minesBeyondFloor": 4,
  "expansionRefusals": 54,
  "expansionBlocked": 63,
  "completedFactories": 2,
  "newFactories": 2,
  "landFactoryTarget": 3,
  "factoryBlocks": 16,
  "builderTarget": 1,
  "builderRecoveries": 0,
  "builderOrders": 0,
  "battleGameTimeMs": 1201040,
  "gameSecondsPerWallSecond": 4.8,
  "noProgressWindowMs": 20000,
  "noProgressCooldownMs": 30000,
  "targetNoProgressTriggers": 0,
  "targetRetries": 0,
  "targetSuppressionsStarted": 4,
  "targetSuppressionsReleased": 0,
  "targetSuppressedSelections": 3,
  "targetSuppressionsAtEnd": 4,
  "targetSwitches": 53,
  "effectiveDecisionIntervalGameMs": 3152,
  "noProgressAttentionGapMs": 9456,
  "maxObservedGameTimeJump": 3616,
  "observationCount": 411,
  "spendTotal": 91850,
  "spendByCategory": {
    "FACTORY_UPGRADE": {
      "orders": 3,
      "cost": 6000
    },
    "UNIT_PRODUCTION": {
      "orders": 100,
      "cost": 58850
    },
    "NEW_MINE": {
      "orders": 6,
      "cost": 4200
    },
    "NEW_FACTORY": {
      "orders": 2,
      "cost": 1400
    },
    "STRATEGIC_CAPABILITY": {
      "orders": 10,
      "cost": 20000
    },
    "STRATEGIC_CONSTRUCTION": {
      "orders": 2,
      "cost": 1400
    }
  },
  "measuredIncomePerGameSecond": 86.07,
  "investmentIntentions": 7,
  "investmentCompletions": 3,
  "investmentCancellations": 4,
  "investmentReserveAtEnd": 0,
  "investmentPendingAtEnd": false,
  "finalUrgency": "CONTESTED",
  "reconEnabled": true,
  "reconTasksCreated": 11,
  "reconOrdersQueued": 22,
  "reconOrdersObserved": 5,
  "reconMovesCompletedBetweenSamples": 8,
  "frontierTasksSatisfiedByTeamVision": 1,
  "reconResolvedAfterObservedMove": 3,
  "reconReacquired": 5,
  "reconSitesCleared": 0,
  "reconBlocked": 1,
  "reconTaskPendingAtEnd": false,
  "reconFrontierEnabled": true,
  "frontierTasksCreated": 5,
  "frontierTasksRefreshed": 0,
  "frontierTasksAdvanced": 1,
  "frontierTasksBlocked": 1,
  "frontierTasksPreempted": 2,
  "expendableTransfers": 2,
  "expendableScoutsAtEnd": 0,
  "factoryTargetIncreases": 1,
  "factoryTargetIncreaseBlocks": 2,
  "landFactoryTargetAtEnd": 3,
  "factoryTargetCommittedAtEnd": false,
  "landFactoryTargetMax": 5,
  "factorySaturationPct": 30.78,
  "factorySaturationMinPct": 80,
  "economyBaseIncome": 26.9,
  "economyIncomePerMine": 12.07,
  "economyModelSource": "MEASURED_4_MATCHES_2_SPEEDS_T1_R2_0.999_T2_T3_ESTIMATED_FROM_FROZEN_GENERATION_RATIOS",
  "minesReadyAtEnd": 7,
  "productionConsumptionPerGameSecond": 37.3,
  "sustainableSurplusPerGameSecond": 74.1,
  "strategy": {
    "enabled": true,
    "armyTarget": 60,
    "activeTarget": 48,
    "reserveTarget": 12,
    "hardSafetyCap": 128,
    "builderTarget": 2,
    "capabilityNeedsAtEnd": 4,
    "needsResolvedByLegalEvidence": 0,
    "investmentOrders": 12,
    "mineUpgradesObserved": 0,
    "constructionCompletionsObserved": 2,
    "capabilityReservesStarted": 5,
    "capabilityReservesReleased": 5,
    "capabilityReserveAtEnd": 0.0
  }
}
```

## run-20261001T043840-d97647/episode-001/rw-agent-reports/bootstrap-1790829523314-96c211ec.jsonl

**阶段** ready_preflight；**扩张** —

Completed own builder available; fresh preflight permits Match

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "Completed own builder available; fresh preflight permits Match",
  "phase": "ready_preflight",
  "bootstrapMode": "AUTOMATIC_NATIVE_PRODUCTION",
  "commands": 1,
  "automaticProductionCommands": 1,
  "observations": 7,
  "queueObserved": true,
  "producerId": 184,
  "builderId": 202,
  "resolvedBuilderType": "builder",
  "completionEvidence": "NEW_OWN_UNIT_AND_NATIVE_QUEUE_CYCLE",
  "gameBudgetSeconds": 180,
  "wallBudgetSeconds": 120
}
```

## run-20261001T043840-d97647/episode-001/rw-agent-reports/development-1790829531732-593bb34d.jsonl

**阶段** tank_observe；**扩张** LIMIT_REACHED

Tank target completed; mines 1/1; expansion LIMIT_REACHED; all task units alive

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "Tank target completed; mines 1/1; expansion LIMIT_REACHED; all task units alive",
  "phase": "tank_observe",
  "commands": 7,
  "observations": 27,
  "completedMines": 1,
  "completedTanks": 6,
  "expansionStatus": "LIMIT_REACHED",
  "scoutMoves": 0,
  "scoutArrivals": 0,
  "scoutBlocked": 0,
  "scoutedMines": 0,
  "scoutRetreats": 0,
  "escortsAssigned": 0,
  "escortsConfirmed": 0,
  "newlyExploredTiles": 0
}
```

## run-20261001T043840-d97647/episode-001/rw-agent-reports/economy-1790829525857-8f783596.jsonl

**阶段** tank_1_produce；**扩张** —

New landFactory completed; its queue was observed active then empty; one new own tank appeared nearby

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "New landFactory completed; its queue was observed active then empty; one new own tank appeared nearby",
  "phase": "tank_1_produce",
  "commands": 2,
  "observations": 14,
  "completedBuildings": 1,
  "completedTanks": 1
}
```
