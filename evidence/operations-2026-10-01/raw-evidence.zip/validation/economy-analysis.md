# 经济冗余诊断与本轮支出边界

日期：2026-10-01（Asia/Shanghai）。只读诊断使用用户新桌面报告；工程边界是待测政策，不能当最优参数或胜率证据。

最新 Spain raw：`游戏环境/P1F-Astra-SpecialistLifecycle-2026-10-01/rw-agent-reports/battle-1790786040776-224cbca9.jsonl`。
SHA256：`5f42806a8398f543d248203937b37ccbaf9c833f8b5ad2e54ba7926eee785c92`。对应候选 JAR `b3e172de9ba54e9ebfd8da1f6787c72ad9f9f7a8702e42cdc63cc948bc57e71e`。地图路径、难度和 Match 前 builder 的操作者上下文由 root 独立核对；本诊断不补猜。

| raw 行 | 游戏绝对时间 ms | 余额 | 观察武装单位 / 策略目标 | 工厂状态 / 机制 |
| --- | ---: | ---: | --- | --- |
| 4938 | 1154679 | 11475 | 66 / 94 | 生产菜单：570/2919 空队列；重炮原生报价可购 |
| 6504 | 1449369 | 21705 | 97 / 96（容量行6405） | 三座工厂，两座空闲 |
| 7514 | 1646124 | 63126.5 | 97 / 92（容量行7391） | 三座工厂全部空闲 |
| 8386 / 8424 | 1801569 / 1809729 | 103017.5 / 102178 | 95 / 96 | 仍选 T2 矿投资，仅缺1军力槽 |
| 9825 / 9859 | 2072674 / 2081604 | 159165 / 158251 | 93 / 94 | 仍选 T2 矿投资，仅缺1军力槽 |
| 12526 | 末尾窗口 | 219018.5 | activeArmy=93 | production_idle=STRATEGY_ARMY_TARGET_REACHED |
| 12584 | 末尾窗口 | 原菜单可负担 | 原生菜单 | heavyArtillery 3100、c_laserTank 1600、c_mammothTank 3900 |
| 12587 | 2507954 | 222397 | 97 / 96 | 三座工厂全部空闲 |
| 12591 | summary | — | — | PARTIAL / ONGOING，2401.120 Battle 秒 |

按相邻己方观察区间、前一区间武装数与当时 target 复算，753.555 / 2401.120 游戏秒观察军力达到 target；不含待产单位，不是完整 committed 占额证明。余额>10000、工厂空闲且观察武装数低于 target 的生产菜单有87次。末尾模型收入268.3/s、近窗口生产消费85.3/s；16次矿升级支出22400、单位支出125400。不能据此证明未来重炮收益，也不把继续扩大工厂或 cap 当消化盈余方案。

本轮选择：

1. 接近军力 target、收入已超过已观察生产消费、且支付真实升级价后仍有充分钱包缓冲时，延后新升矿。接近定义为缺口<=max(2,ceil(target*0.1))，钱包缓冲为 max(30秒当前模型收入, 两次原生普通补兵报价)。保留原 activeForce、安全、储备、回本判断；报价未知不强行宣布饱和。
2. 在原军力槽位内补少量 heavyArtillery 围城角色，数量上限 min(6,target/12)。普通可用主力至少24、基地无紧急威胁、当前合法可见 SURFACE 建筑、原生菜单可负担且空队列；购买后保留全部共享储备和两次普通补兵的钱。
3. 已接单重炮与 ready 成品唯一匹配：排队清空但成品未观察时保留 pending；一个新 ready 自身ID只履约一次；计数为 ready 存量+pending。该匹配明确是观察可用角色，不证明生产者来源。生产者损失或180游戏秒未观察成品，带原因释放。全局cap仍由现有全部队列、工程师、施工待产的 committed bound 保护，重炮无 native queue 的 ghost 额外计入。

资料来源：

- `游戏资料/20_整理与结构化资料/README.md` 最后段要求具体数值回原始来源与冻结版本验证。
- `星星版铁锈机制库_清洗转写.txt` SHA256 `dc4380a7cb6c9a4f036a888831d06a476ee3517efb2d5ec0f792772ab41d5254`；行34/38为重型火炮伤害概述，行222为速度0.6；行169–189为矿/制造仪回本概述。行137是火炮机甲34，不是重型火炮满续兵价。
- 冻结 `游戏环境/rustedwarfare PC 1.15 原版/assets/units/tanks/heavy_artillery.ini` SHA256 `a03d396d96a56c6d942a916abff49f09b2e7dcf7220f05ab5f2f5fcfb31be22c`：行11 price3100，行12 hp600，行56–59攻域，行65 range310，行139–140 LAND/speed0.6。对地可攻、对空和水下不可攻；STATIC_INI 不表示已观察原生实战收益。

新增实现：`agent/src/io/rwagent/client/SurplusSpendingPolicy.java` 为纯输入/输出 helper；合同 `agent/tests/SurplusSpendingHarness.java`，HTTP 时间线 `agent/tests/test_surplus_spending.py`。暂由 root 顺序集成 BattleClient 和 StrategyDirector；本子任务不编辑共享生产文件，不启动/关闭桌面游戏，也不运行完整回归。

独立 helper/Harness 以 JDK17 `--release 8` 在 `economy-policy` 编译执行，最终42项合同 PASS（包括未知队列占额）。最初六个 HTTP 场景使用冻结旧候选做负对照：四个保护边界通过，两项目标行为预期失败，耗时17.285s。富余资金旧代码没有重炮订单；矿业原代码在8000/16000/24000游戏毫秒分别接受1400升级，共4200。之后新增硬cap HTTP 边界单独执行8.468s，旧代码只买重坦，未买期望的重炮角色；此场要求新候选整个时间线只有1笔重炮订单，已付费尚未观察成品的窗口也不准普通生产再填最后一个hard128槽位。新代码七场 HTTP 尚待 root 集成后验证；`old-surplus-http` 保存原始输入、native debit菜单、全部客户端报告事件和stdout。

合流后矿场景复核：原 fixture 的动态 armyTarget 随收入支持可增到52，使后期成为真实较大軍力缺口，合法允许重新投资矿；这不应被强行当政策失败。最终仅该场景设置真实 `mobileUnitHardCap=40`，39普通军力在整个时间线维持1槽缺口；无矿订单断言保留，并增加所有容量target=40及拒绝缺口满足near-target的断言。root 最新合流 JAR（`source/agent/dist/rw-agent-bootstrap.jar`，初次普通报价读取已修）执行最终矿单场2.892s PASS；输入/事件保存在 `fixed-surplus-http/mine_saturated.json`。其他六场不受fixture修改影响；完整矩阵由root汇总。
