"""Create a task-local native map fixture; the original assets are read-only."""
import base64
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import struct
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parent
original=Path(r'G:\deepseek 工作台\游戏环境\rustedwarfare PC 1.15 原版')
isolated=root/'base-only-resource-game'
isolated.mkdir(exist_ok=False)
def link(source,target):
    try:target.symlink_to(source,target_is_directory=source.is_dir())
    except OSError:
        if source.is_dir():shutil.copytree(source,target)
        else:shutil.copy2(source,target)
for name in ('game-lib.jar','libs','res'):link(original/name,isolated/name)
assets=isolated/'assets';assets.mkdir()
for source in (original/'assets').iterdir():
    if source.name=='maps':shutil.copytree(source,assets/source.name)
    else:link(source,assets/source.name)
source=original/'assets/maps/skirmish/[p2]Big Island (2p).tmx'
tree=ET.parse(source)
firstgid=next(int(t.get('firstgid')) for t in tree.findall('tileset') if t.get('source')=='units.tsx')
builders=[]
for tile in ET.parse(original/'assets/tilesets/units.tsx').findall('tile'):
    props={p.get('name'):p.get('value') for p in tile.findall('properties/property')}
    if props.get('unit')=='builder' and props.get('team')=='0':builders.append(firstgid+int(tile.get('id')))
removed=[]
for layer in tree.findall('layer'):
    if layer.get('name').lower()!='units':continue
    data=layer.find('data');assert data.get('encoding')=='base64' and data.get('compression')=='gzip'
    raw=gzip.decompress(base64.b64decode(data.text))
    tiles=list(struct.unpack('<%dI'%(len(raw)//4),raw))
    for index,gid in enumerate(tiles):
        if (gid & 0x1fffffff) in builders:
            removed.append({'layer':layer.get('name'),'tileIndex':index,'originalGid':gid});tiles[index]=0
    data.text='\n'+base64.b64encode(gzip.compress(struct.pack('<%dI'%len(tiles),*tiles),mtime=0)).decode()+'\n'
assert len(removed)==1,removed
target=assets/'maps/skirmish/[p2]Big Island BaseOnly Fixture (2p).tmx'
tree.write(target,encoding='UTF-8',xml_declaration=True)
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
manifest={'schemaVersion':1,'scope':'CONTROLLED_NATIVE_MAP_FIXTURE_NOT_UNMODIFIED_SPAIN_OR_DESKTOP',
          'sourceMap':str(source),'sourceMapSha256':sha(source),'fixtureMap':str(target),
          'fixtureMapSha256':sha(target),'removedMapSpawns':removed,
          'originalEngineSha256':sha(original/'game-lib.jar'),
          'change':'Remove only team0 initial builder tile; retain all terrain, resources, bases and AI units.',
          'runtimeInitialStateMustVerifyNoReadyBuilder':True,'userPreferencesCopied':False}
(root/'base-only-fixture-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(manifest,ensure_ascii=False,indent=2))
