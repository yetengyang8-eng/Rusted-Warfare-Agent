package io.rwagent.client;
public final class BudgetEntryHarness {
    public static void main(String[] args) {
        if(BattleBudget.seconds(new String[]{"4800"})!=4800)throw new AssertionError("4800 budget");
        if(BattleBudget.gameLimit()!=7200)throw new AssertionError("game safety");
        if(BattleBudget.wallLimit()!=3600)throw new AssertionError("wall safety");
        boolean rejected=false;
        try{BattleBudget.seconds(new String[]{"7201"});}catch(IllegalArgumentException expected){rejected=true;}
        if(!rejected)throw new AssertionError("safety upper bound");
        System.out.println("LONG_ENTRY_BUDGET_OK checks=4 gameSeconds=4800 gameSafety=7200 wallSafety=3600");
    }
}
