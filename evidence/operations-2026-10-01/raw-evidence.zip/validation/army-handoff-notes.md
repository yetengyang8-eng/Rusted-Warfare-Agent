# 2026-10-01 局部控兵交接材料

本文供 root 合入 GPT / DeepSeek 交接。最终合流源码提交、最终候选 JAR 身份、完整回归与原生结果由 root 的最终记录补齐；本文件的专项 JAR 是中间快照，不能代替最终验收。

原有冻结基线仍为 RW-BASELINE-2026-09-30-GS-v1，本次从仓库最新 8109e11 的 Specialist Lifecycle 增量继续。默认源码仍为 GitHub发布/Rusted-Warfare-Agent/agent 与 tools。工程师、侦察、返回任务的 ownership 和 UNKNOWN 边界继续保留。

最新桌面长局 raw 位于 `G:\deepseek 工作台\游戏环境\P1F-Astra-SpecialistLifecycle-2026-10-01\rw-agent-reports\battle-1790786040776-224cbca9.jsonl`，SHA256 `5f42806a8398f543d248203937b37ccbaf9c833f8b5ad2e54ba7926eee785c92`。读取前后大小及修改时间稳定，以 summary 结束。该局末态 raw 12587 有 95 个非工程师移动武装单位；200 / 400 地图半径连通分组均得到 44 / 25 / 15 / 6 / 4 / 1 六团。

直接促成改动的证据：raw 9678 / 9679 对当前 c_antiAirTurret #22234 的 (3900,2160) 下令；9707 / 9708 改向旧记忆 airFactory #21030 的 (5470,5250)；9737 / 9738 再改向当前 c_turret_t2_gun #31318 的 (3500,2640)。三次 actor 集合完全相同，均为 48 人，13.395 游戏秒内目标坐标跳转 3466 和 3270。另 raw 8772 / 8773 scout #28568 至 8798 / 8799 hoverTank #28098，相隔 5.785 游戏秒，目标坐标变化 3202.6，同样 48 人均距离新目的地超过 2000。这些证明控制指令牵引，不直接证明它们造成了全部战损。

实现由 `LocalArmyDirector.java` 保存 default main owner 内的己方 cohort 映射。`BattleClient.java` 的 tactics 在至少两支 cohort 时进入局部流程；单团继续既有流程。并未新增 arbiter lease：真实工程师 / Recon task 的租约优先，mainArmy 先排除专属单位、expendable scout、Recall 和休息中的伤员，控制器仅接收剩余主力。

- 最多 4 队，每队最多 48 人，附近至少 6 人才建立独立队伍；少于 3 人释放，剩余成员归附近可用队伍。
- 成组半径 400 地图单位；已有队伍中距锚点至少 1000、聚集至少 6 人的远处成员可形成独立队。队伍路线交叉不会自动合并和重贴标签。
- 每队保存独立 targetId、上次原生接受命令的游戏时间、目标坐标、前沿锚点和进展。局部目标范围 1400，失联局部记忆最多保持 30 游戏秒；这些是待自然验证的初始工程参数。
- 目标判断继续调用原 targetGuard、strategy.eligible、deprioritized 和 targetSuppressions。未知仍是未知，明确不兼容继续拒绝，不用到达或失联宣称击杀。
- 所有队伍先观察进展，之后轮流执行最多一个动作。同目标队伍用实际分配 actor 并集调用原无进展守卫。原生接受命令后才记本队时间和轮转位置；共享 CommandArbiter 仍限制至少 1 游戏秒命令间隔。
- 无局部敌情时各队使用自己的 scout-plan 前沿；当完全探索导致无剩余前沿时，当前可见的远方接触提供本队的推进目标，事件理由为 REMOTE_VISIBLE_CONTACT。该出口不追失联的远方旧记忆。

新增测试 `LocalArmyContractHarness.java` 与 `test_local_army.py`。专项验证为合同 372 项通过、新 HTTP 七场全部通过、原冻结 Specialist Lifecycle JAR 在同样七场中六场预期失败而单团保留场通过。既有 target_compatibility 15 场继续通过。七场分别覆盖双团各自目标、近处新增目标及远处接触不替换已有局部目标、两团无敌前沿连续推进、无前沿时当前远方接触、UNKNOWN / 潜水负证据 / 工程师隔离、原生拒绝后重试与轮转、无进展观察不被另一队命令饥饿、单团旧流程。

专项证据目录为 `G:\deepseek 工作台\_validation\operations-20261001\local-army`：`logs/http-final` 与 `logs/http-old` 保留每场 raw、orders 和进程输出；`new-http.log` / `old-http.log` / `target-compatibility.log` / `contract.log` 保留结果；`validation-summary.json` 汇总身份。中间 JAR 为 `dist/rw-agent-bootstrap.jar`，SHA256 `6ba4ece9ba0d61724f302f621dcbb47dc4504724c9e6109af2778f24fb4e429a`，属于经济合流前专项，不能冒用为最终候选。专项均为 E2_REAL_CLIENT_HTTP_NO_NATIVE_GAME，不代表自然对局收益。

合流只读审查发现并由 root 修复了两个承诺数量缺口：重炮原生队列已空、成品尚未观察的 ghost slot 原先只进入普通生产，未进入更早执行的 StrategyDirector 采购 / 支援生产 hard-cap；普通生产在同一 ghost 期间也可能超过 soft armyTarget。现在 BattleClient 在 strategy.observe 前注入 noteUnobservedCombatSlots；Strategy 的 safetyCapacityAvailable 包含它，committedArmedForPolicy 保留原始口径，SurplusSpendingPolicy 不会重复加 ghost。普通 productionLimit 同时比较 min(armyTarget, hardCap)。root 的 StrategyContract 新增三项后为 169 项通过。复读修复代码后，无其他必须修的合流问题。

仍待最终候选原生确认的内容包括多队自然成组、队伍独立推进效果、可见远接触出口和与新增重炮的共同执行。没有引入单位造价战力、全军危机信号预测、护送、修理或撤退路线；专项不声称收益、胜率或终局能力。原版引擎、用户桌面、游戏设置、存档与回放均未由本子任务修改。
