"""Collect test results and compare fixed/native and full-regression build identity."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'source/tools'))
from run_headless import jar_content_digest


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def entries(path):
    with zipfile.ZipFile(path) as archive:
        return {name: hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist()
                if name != 'META-INF/MANIFEST.MF'}


paths = {'fixedCandidate': ROOT / 'fixed-candidate/rw-agent-bootstrap.jar',
         'fullRegressionRebuild': ROOT / 'source/agent/dist/rw-agent-bootstrap.jar'}
builds = {label: dict(path=str(path), bytes=path.stat().st_size, wholeSha256=sha(path),
                      contentDigest=jar_content_digest(path), entriesExcludingManifest=len(entries(path)))
          for label, path in paths.items()}
for label, path in paths.items():
    with zipfile.ZipFile(path) as archive:
        builds[label]['directoryEntries'] = sum(info.is_dir() for info in archive.infolist())
        builds[label]['fileEntriesExcludingManifest'] = sum(not info.is_dir() and info.filename != 'META-INF/MANIFEST.MF' for info in archive.infolist())
fixed, rebuilt = (entries(paths[key]) for key in ('fixedCandidate', 'fullRegressionRebuild'))
different = [name for name in sorted(set(fixed) | set(rebuilt)) if fixed.get(name) != rebuilt.get(name)]
lineage = dict(algorithm='tools/run_headless.py:jar_content_digest', builds=builds,
               manifestExcluded=True, directoryEntriesIncluded=True, contentEqual=not different, differingEntries=different)
write(ROOT / 'jar-lineage.json', lineage)

full = ROOT / 'full'
transcript_path = full / 'full-regression.log'
transcript = transcript_path.read_text(encoding='utf-8-sig', errors='replace')
steps = []
for match in re.finditer(r'^=== ([^\r\n]+) ===\s*\n(.*?)(?=^=== |^===== SUMMARY|\Z)', transcript, re.MULTILINE | re.DOTALL):
    name, body = match.groups()
    terminal = re.search(r'^--> (PASS|FAIL) exit=(-?\d+)', body, re.MULTILINE)
    log_name = re.sub('[^A-Za-z0-9_.-]', '_', name) + '.log'
    path = ROOT / 'source/agent/build/logs' / log_name
    raw = path.read_text(encoding='utf-8-sig', errors='replace') if path.exists() else ''
    row = dict(step=name, status=terminal.group(1) if terminal else 'RUNNING',
               exitCode=int(terminal.group(2)) if terminal else None, rawLog='raw-logs/' + log_name)
    if path.exists():
        row['rawLogSha256'] = sha(path)
    tests = re.search(r'Ran (\d+) tests? in ([0-9.]+)s', raw)
    if tests:
        skipped = re.search(r'OK \(skipped=(\d+)\)', raw)
        row.update(testsRun=int(tests.group(1)), seconds=float(tests.group(2)),
                   skipped=int(skipped.group(1)) if skipped else 0)
    row['skipLines'] = [line for line in raw.splitlines() if '_SKIP ' in line or ' ... skipped ' in line]
    contract = re.search(r'STRATEGY_CONTRACT_TEST_OK checks=(\d+)', raw)
    if contract:
        row['contractChecks'] = int(contract.group(1))
    steps.append(row)
final = re.search(r'Java harness runs: (\d+)\s+Python suites: (\d+)\s+failed steps: (\d+)', transcript)
exit_path = full / 'exit-code.txt'
run_exit = int(exit_path.read_text(encoding='utf-8-sig').strip()) if exit_path.exists() else None
passed = final is not None and final.group(3) == '0' and run_exit == 0 and len(steps) == 47 and all(row['status'] == 'PASS' for row in steps)
summary = dict(status='PASS' if passed else 'INCOMPLETE_OR_FAILED', runnerExitCode=run_exit,
               stepCount=len(steps), javaHarnessRuns=int(final.group(1)) if final else None,
               pythonSuites=int(final.group(2)) if final else None, failedSteps=int(final.group(3)) if final else None,
               pythonTestsRun=sum(row.get('testsRun', 0) for row in steps), pythonSkipped=sum(row.get('skipped', 0) for row in steps),
               strategyContractChecks=next((row['contractChecks'] for row in steps if 'contractChecks' in row), None),
               steps=steps, transcript='full-regression.log', transcriptSha256=sha(transcript_path),
               fixedAndRegressionJarContentEqual=not different,
               fixedCandidateSha256=builds['fixedCandidate']['wholeSha256'],
               candidateContentDigest=builds['fixedCandidate']['contentDigest'])
write(full / 'summary.json', summary)
if final is not None:
    (full / 'raw-logs').mkdir(exist_ok=True)
    for source in (ROOT / 'source/agent/build/logs').glob('*.log'):
        shutil.copy2(source, full / 'raw-logs' / source.name)
print(json.dumps({key: value for key, value in summary.items() if key != 'steps'}, ensure_ascii=False, indent=2))
assert passed and not different

