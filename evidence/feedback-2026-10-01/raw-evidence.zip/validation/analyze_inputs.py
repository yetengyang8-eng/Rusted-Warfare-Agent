"""Read-only bounded streaming evidence for 2026-10-01 desktop feedback."""
import collections
import hashlib
import json
import math
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

ROOT = Path(r"G:\deepseek 工作台\_validation\feedback-20261001")
ENV = Path(r"G:\deepseek 工作台\游戏环境\P1F-GPTSol61-Operations-2026-10-01")
RAW = ENV / "rw-agent-reports"

def hash_file(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def dist(a,b):
    return math.hypot(a.get('x',0)-b.get('x',0),a.get('y',0)-b.get('y',0))

def analyze(path):
    stat_before=path.stat()
    h=hashlib.sha256()
    counts=collections.Counter(); reasons=collections.defaultdict(collections.Counter)
    state={}; state_line=0; previous_own={}; own={}; enemies={}; combat_line=0
    cohort={}; cohort_history=collections.defaultdict(list); mode=None
    orders=[]; action=None; accepted=[]; action_attempts=[]
    loss_examples=[]; damage_examples=[]; mine_holds=[]; menus={}; investment_menu={}
    expansion_blocks=[]; engineer_menus=[]; support_orders=[]; own_loss=[]
    max_order_age=[]; latest_hp_drops=[]; first_time=None; last_time=None
    summary={}; health={}; provenance={}; config={}; first_state={}
    latest_urgency={}; urgency_counts=collections.Counter()
    most_recent_order={}; prev_attack=None; tug=[]; tug_after_mode=[]
    latest_scout={}; scout_line=0; intent=None; window_actions=[]; window_observations=[]; loss_boundary=[]
    with path.open('rb') as f:
        for line_no, line in enumerate(f,1):
            h.update(line); o=json.loads(line); ev=o.get('event'); d=o.get('data',{})
            counts[ev]+=1
            if path.name=='battle-1790834102177-db78fa55.jsonl' and 11930<=line_no<12884:
                if ev=='action':window_actions.append(dict(d,line=line_no))
                if ev=='observation':window_observations.append({'line':line_no,'gameTimeMs':d['gameTimeMs']})
            if isinstance(d,dict) and d.get('reason'): reasons[ev][str(d['reason'])]+=1
            if ev=='health': health=d
            if ev=='report_provenance': provenance=d
            if ev=='battle_config': config=d
            if ev=='summary': summary=d
            if ev=='scout_visibility': latest_scout=d; scout_line=line_no
            if ev=='military_urgency': latest_urgency=dict(d,line=line_no)
            if ev=='observation':
                state=d; state_line=line_no; t=d['gameTimeMs']; last_time=t
                if first_time is None: first_time=t; first_state=d
                previous_own=own; own={u['id']:u for u in d.get('ownUnits',[])}
                urgency_counts[latest_urgency.get('state','UNKNOWN')]+=1
                latest_hp_drops=[]
                for uid,u in own.items():
                    prev=previous_own.get(uid)
                    if prev and prev.get('hp',0)>u.get('hp',0)+.1 and u.get('building'):
                        latest_hp_drops.append({'unit':u,'hpBefore':prev['hp'],'hpNow':u['hp'], 'observationLine':line_no,'gameTimeMs':t})
                if mode:
                    for cid,members in cohort.items():
                        active=[own[uid] for uid in members if uid in own]
                        if not active: continue
                        order=most_recent_order.get(cid)
                        if order:
                            age=t-order['gameTimeMs']
                            if age>30000:
                                center={'x':sum(u['x'] for u in active)/len(active),'y':sum(u['y'] for u in active)/len(active)}
                                sample={'cohortId':cid,'gameTimeMs':t,'observationLine':line_no,'timeSinceLastAcceptedOrderSeconds':age/1000,'lastOrderLine':order['line'],'lastOrderReason':order.get('reason'),'lastTargetId':order.get('targetId'),'observedMembers':len(active),'unitsWithNoOrder':sum(u.get('orderType') is None for u in active),'orderTypes':dict(collections.Counter(str(u.get('orderType')) for u in active)),'center':center}
                                max_order_age.append(sample)
                                max_order_age=sorted(max_order_age,key=lambda q:q['timeSinceLastAcceptedOrderSeconds'],reverse=True)[:20]
            if ev=='combat_observation':
                enemies={u['id']:u for u in d.get('visibleEnemies',[])}; combat_line=line_no
                t=d.get('gameTimeMs',last_time or 0)
                for drop in latest_hp_drops:
                    u=drop['unit']; nearby=[e for e in enemies.values() if e.get('canAttack') and dist(e,u)<=450]
                    ready_mobile=[a for a in own.values() if a.get('mobile') and a.get('canAttack') and not a.get('dead') and a.get('buildProgress',0)>=1 and a.get('type')!='combatEngineer']
                    near_own=sorted([a for a in ready_mobile if dist(a,u)<=1000],key=lambda a:dist(a,u))
                    if 1<=len(nearby)<=3 and (str(u.get('type','')).startswith('extractor') or u.get('type') in ('commandCenter','landFactory')):
                        q={k:v for k,v in drop.items() if k!='unit'}
                        q.update({'asset':u,'combatLine':line_no,'combatGameTimeMs':t,'visibleArmedWithin450':nearby,'ownReadyMilitaryWithin1000':[{k:a.get(k) for k in ('id','type','x','y','hp','maxHp','orderType')} for a in near_own[:10]],'ownNearCount':len(near_own),'nearestCohort':[]})
                        for cid,members in cohort.items():
                            aa=[own[uid] for uid in members if uid in own]
                            if aa:q['nearestCohort'].append({'cohortId':cid,'members':len(aa),'minimumDistance':min(dist(a,u) for a in aa),'lastOrder':most_recent_order.get(cid)})
                        damage_examples.append(q)
                latest_hp_drops=[]
            if ev=='local_army_membership':
                cid=d['cohortId']; cohort[cid]=list(d.get('unitIds',[]))
                if not cohort[cid] or d.get('reason')=='RELEASED_BELOW_THREE': cohort.pop(cid,None)
                cohort_history[cid].append(dict(d,line=line_no))
            if ev=='local_army_mode' and d.get('active'): mode=dict(d,line=line_no)
            if ev=='local_army_order':
                order=dict(d,line=line_no); orders.append(order); most_recent_order[d['cohortId']]=order
            if ev=='tactical_intent':intent=dict(d,line=line_no)
            if ev=='action':
                action=dict(d,line=line_no);action_attempts.append(action)
                if d.get('path','').startswith('/command/attack-move'):
                    q=parse_qs(urlsplit(d['path']).query)
                    ids=set(int(i) for i in q.get('unitIds',[''])[0].split(',') if i)
                    p={'line':line_no,'gameTimeMs':d.get('gameTimeMs',last_time),'x':float(q.get('x',['0'])[0]),'y':float(q.get('y',['0'])[0]),'ids':ids,'intent':intent}
                    if prev_attack:
                        elapsed=p['gameTimeMs']-prev_attack['gameTimeMs']; common=len(ids&prev_attack['ids']); jump=math.hypot(p['x']-prev_attack['x'],p['y']-prev_attack['y'])
                        if 0<=elapsed<20000 and jump>1500 and common>=12:
                            hit={'fromLine':prev_attack['line'],'toLine':line_no,'elapsedSeconds':elapsed/1000,'sharedActors':common,'destinationJump':jump}
                            tug.append(hit)
                            if mode and prev_attack['gameTimeMs']>=mode['gameTimeMs']:tug_after_mode.append(hit)
                    prev_attack=p
            if ev=='command_result' and d.get('status')=='queued' and action:
                accepted.append(dict(action,receipt=d)); action=None
            if ev=='mine_income_investment_deferred':
                mine=own.get(d.get('mineId'),{})
                nearby=[e for e in enemies.values() if e.get('canAttack') and mine and dist(e,mine)<=450]
                q=dict(d,line=line_no,observationLine=state_line,menuLine=investment_menu.get('line'),nativeMine=mine,visibleArmedWithin450=nearby)
                mine_holds.append(q)
            if ev=='strategy_investment_menu':investment_menu=dict(d,line=line_no)
            if ev=='economy_expansion_blocked':
                if len(expansion_blocks)<60 or d.get('reason')=='NO_INVESTMENT_INTENT':
                    resources=latest_scout.get('resources',[])
                    builders=[u for u in own.values() if u.get('type')=='builder']
                    available=[]
                    for r in resources:
                        if not isinstance(r,dict) or not all(isinstance(r.get(k),(int,float)) for k in ('x','y')): continue
                        if any(str(u.get('type','')).startswith('extractor') and dist(u,r)<80 for u in own.values()):continue
                        close=[e for e in enemies.values() if e.get('canAttack') and dist(e,r)<=450]
                        if not close:available.append(r)
                    available.sort(key=lambda q:(not q.get('currentlyVisible',False),min((dist(q,b) for b in builders),default=0)))
                    expansion_blocks.append(dict(d,line=line_no,observationLine=state_line,urgency=latest_urgency,credits=state.get('player',{}).get('credits'),scoutLine=scout_line,resourceSamples=available[:8],ownBuilders=builders,visibleEnemyCount=len(enemies),evidenceLimit='No visible armed enemy within450 does not prove hidden route/site safety. Resource flags must be interpreted by the production planner.'))
            if ev=='strategy_production_menu':
                engineer=[q for q in d.get('factories',[]) if own.get(q.get('id'),{}).get('type')=='combatEngineer']
                if engineer: engineer_menus.append(dict(line=line_no,gameTimeMs=last_time,engineerMenus=engineer))
            if ev=='strategy_construction_ordered':support_orders.append(dict(d,line=line_no))
            if ev=='own_loss':
                own_loss.append(dict(d,line=line_no))
                if 4303000<=d.get('gameTimeMs',-1)<=4305000:loss_boundary.append(dict(d,line=line_no))
                u=d.get('unit') or d
                if not str(u.get('type','')).startswith('extractor'): continue
                close=sorted(enemies.values(),key=lambda e:dist(e,u))[:3]
                loss_examples.append(dict(d,line=line_no,combatLine=combat_line,nearestVisible=close))
    stat_after=path.stat()
    by_cohort={}
    for cid in cohort_history:
        oo=[q for q in orders if q['cohortId']==cid]
        gaps=[{'fromLine':a['line'],'toLine':b['line'],'fromTimeMs':a['gameTimeMs'],'toTimeMs':b['gameTimeMs'],'gapSeconds':(b['gameTimeMs']-a['gameTimeMs'])/1000,'fromReason':a['reason'],'toReason':b['reason']} for a,b in zip(oo,oo[1:])]
        by_cohort[cid]={'acceptedOrders':len(oo),'membershipEvents':len(cohort_history[cid]),'maximumAcceptedOrderGap':max(gaps,key=lambda q:q['gapSeconds']) if gaps else None,'gapsOver60Seconds':sum(q['gapSeconds']>60 for q in gaps),'firstMembership':cohort_history[cid][0],'lastMembership':cohort_history[cid][-1]}
    def bins(origin):
        return dict(sorted(collections.Counter((q['gameTimeMs']-origin)//600000 for q in orders).items())) if origin is not None else {}
    intervals=[b['gameTimeMs']-a['gameTimeMs'] for a,b in zip(accepted,accepted[1:])]
    categories=collections.Counter(urlsplit(q['path']).path for q in accepted)
    last_window_losses=[q for q in own_loss if q.get('gameTimeMs',0)>=(last_time or 0)-600000]
    damage_examples.sort(key=lambda q:(-q['ownNearCount'],q['gameTimeMs']))
    result={'file':str(path),'sha256':h.hexdigest(),'bytes':stat_after.st_size,'lines':line_no,'stableRead':(stat_before.st_size,stat_before.st_mtime_ns)==(stat_after.st_size,stat_after.st_mtime_ns),'health':health,'provenance':provenance,'config':config,'eventCounts':dict(counts),'eventReasons':{e:dict(c) for e,c in reasons.items()},'initialState':first_state,'lastState':state,'summary':summary,'localArmy':{'mode':mode,'ordersPer600SecondsFromBattleStart':bins(first_time),'ordersPer600SecondsFromLocalMode':bins(mode.get('gameTimeMs') if mode else None),'cohorts':by_cohort,'longestTimeSinceAcceptedOrderSamples':max_order_age,'oldTugDefinitionCount':len(tug),'oldTugDefinitionAfterModeCount':len(tug_after_mode),'oldTugExamples':tug},'commandGate':{'accepted':len(accepted),'attempts':len(action_attempts),'minimumAcceptedActionStampGapMs':min(intervals) if intervals else None,'gapsBelow1000':sum(q<1000 for q in intervals),'acceptedPerGameMinute':len(accepted)*60000/max(1,(last_time or 0)-(first_time or 0)),'acceptedCommandPathCounts':dict(categories),'limit':'Accepted action stamps use preceding legal own observation; no logged gate-denial reason or scheduling opportunity allows causal attribution.'},'mineDeferrals':{'count':len(mine_holds),'first':mine_holds[0] if mine_holds else None,'middle':mine_holds[len(mine_holds)//2] if mine_holds else None,'last':mine_holds[-1] if mine_holds else None,'maximumCredits':max((q['credits'] for q in mine_holds),default=0)},'mineDamageExamples':damage_examples[:15],'mineLossExamples':loss_examples[:10],'expansionBlockExamples':expansion_blocks[:15]+[q for q in expansion_blocks if q['reason']=='NO_INVESTMENT_INTENT' and q.get('resourceSamples')][-6:],'engineerProductionMenuCount':len(engineer_menus),'engineerProductionMenuExamples':engineer_menus[:3],'supportProductionProducts':dict(collections.Counter(q.get('product','UNKNOWN') for q in support_orders)),'last600SecondsLosses':{'total':len(last_window_losses),'types':dict(collections.Counter(q.get('type','UNKNOWN') for q in last_window_losses))}}
    if window_observations:
        result['schedulingWindow']={'fromLine':11930,'untilExclusive':12884,'observations':len(window_observations),'actionAttempts':len(window_actions),'commandPathCounts':dict(collections.Counter(urlsplit(a['path']).path for a in window_actions)),'observationsFirstLast':[window_observations[0],window_observations[-1]],'actions':window_actions,'note':'Each action consumes the shared slot, including native rejection. This explains priority competition but does not prove every absent order had a legal target.'}
    result['lossWindowBoundaryExamples']=loss_boundary
    return result

if __name__=='__main__':
    ROOT.mkdir(parents=True,exist_ok=True)
    files=[RAW/'battle-1790833775271-58c1b659.jsonl',RAW/'battle-1790834102177-db78fa55.jsonl']
    results=[analyze(p) for p in files]
    identities={str(p):{'sha256':hash_file(p),'bytes':p.stat().st_size} for p in [ENV/'rw-agent-bootstrap.jar',ENV/'game-lib.jar',Path(r'C:\Users\Administrator\Desktop\反馈.txt'),Path(r'C:\Users\Administrator\Desktop\agent 思维架构 仓库 4.txt'),ENV/'mods/maps/[10p] 10p 西班牙混战_by_MP97.tmx',ENV/'assets/maps/skirmish/[p2]Big Island (2p).tmx']}
    output={'schemaVersion':1,'analysis':'READ_ONLY_STREAMING_FEEDBACK_20261001','identityFiles':identities,'reports':results,'limitations':['Raw reports do not supply mapPath/difficulty/seed; Spain is operator label.','Order-age measures lack of a new accepted order, not idle or gate cause.','Visible-neighborhood absence is not hidden safety. Damage drops and own_loss do not prove enemy kill attribution.','No desktop process was started, stopped, or changed.']}
    (ROOT/'metrics.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps([{'file':r['file'],'sha256':r['sha256'],'bytes':r['bytes'],'stable':r['stableRead'],'lines':r['lines'],'localArmy':{k:v for k,v in r['localArmy'].items() if k not in ('cohorts','longestTimeSinceAcceptedOrderSamples')},'cohortGaps':{k:v['maximumAcceptedOrderGap'] for k,v in r['localArmy']['cohorts'].items()},'commandGate':r['commandGate'],'mineDeferrals':r['mineDeferrals'],'engineerMenus':r['engineerProductionMenuCount'],'support':r['supportProductionProducts'],'lossesLast600':r['last600SecondsLosses']} for r in results],ensure_ascii=False,indent=2))
