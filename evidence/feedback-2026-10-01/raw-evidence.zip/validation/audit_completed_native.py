"""Read-only final native audits, metrics, provenance and bounded summaries."""
import collections
import hashlib
import json
from pathlib import Path
import sys

REPO=Path(r'G:\deepseek 工作台\GitHub发布\Rusted-Warfare-Agent')
ROOT=Path(r'G:\deepseek 工作台\_validation\feedback-20261001')
sys.path.insert(0,str(REPO/'tools'))
from audit_feedback_progress import audit as feedback
from audit_operations import audit as operations
from audit_global_strategy import audit as global_strategy
from audit_specialist_lifecycle import audit as specialist
from analyze_reports import analyze_file


def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def run(name,runid):
    episode=ROOT/('native-'+name)/runid/'episode-001'
    out=ROOT/'native-audit'/name
    out.mkdir(parents=True,exist_ok=True)
    all_audits=[]
    for path in sorted((episode/'rw-agent-reports').glob('*.jsonl')):
        all_audits.append(dict(file=str(path),sha256=digest(path),feedback=feedback(path),operations=operations(path),
                               globalStrategy=global_strategy(path),specialist=specialist(path),parsed=analyze_file(path)))
    (out/'suite-final.json').write_text(json.dumps(dict(schemaVersion=1,reports=all_audits),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    battle=next(r for r in all_audits if r['parsed']['task']=='battle')
    path=Path(battle['file'])
    counts=collections.Counter();losses=collections.Counter();cohorts={};serial=set();maxcohorts=0
    allocations=[];upgrades=[];transfers=[];first_queries={};query_reasons=collections.Counter();age_samples=[];noorder_ages=[];diag_unknown=0
    first_state={};last_state={};summary={};config={};provenance={};crisis_sizes=[];spends=collections.defaultdict(lambda:dict(count=0,cost=0))
    line_count=0
    for line,raw in enumerate(path.open(encoding='utf-8'),1):
        line_count=line;row=json.loads(raw);e,d=row['event'],row['data'];counts[e]+=1
        if e=='observation':
            if not first_state:first_state=d
            last_state=d
        elif e=='summary':summary=d
        elif e=='battle_config':config=d
        elif e=='report_provenance':provenance=d
        elif e=='local_army_membership':
            key=d.get('cohortId');serial.add(key)
            if d.get('reason')=='RELEASED_BELOW_THREE':cohorts.pop(key,None)
            else:cohorts[key]=d.get('unitIds',[])
            maxcohorts=max(maxcohorts,len(cohorts))
        elif e=='strategy_allocation' and d.get('selected') in ('MINE_T2_INCOME_INVESTMENT','MINE_T3_INCOME_INVESTMENT'):
            allocations.append(dict(line=line,**d))
        elif e=='mine_upgrade_observed':upgrades.append(dict(line=line,**d))
        elif e=='own_loss':losses[d.get('type')]+=1
        elif e=='strategy_support_transferred':transfers.append(dict(line=line,**d))
        elif e=='response_engagement_observation':
            for actor in d.get('actors',[]):
                uid=actor.get('unitId')
                if uid in {t.get('responderId') for t in transfers}:
                    query_reasons[(uid,actor.get('reason'),actor.get('compatibility'),d.get('targetVisible'))]+=1
                    if uid not in first_queries:first_queries[uid]=dict(line=line,evidence=d)
        elif e=='local_army_diagnostic':
            age=d.get('lastAcceptedAgeMs')
            if isinstance(age,(int,float)) and not isinstance(age,bool):
                age_samples.append(age/1000)
                if (d.get('unitsWithNoOrderAwayFromGoal') or 0)>0:noorder_ages.append(age/1000)
            else:diag_unknown+=1
        elif e=='local_crisis_started':crisis_sizes.append(len(d.get('unitIds',[])))
        elif e=='spend':
            q=spends[d.get('category','UNKNOWN')];q['count']+=1;q['cost']+=d.get('cost',0)
    runtime=json.loads((episode/'runtime.json').read_text(encoding='utf-8'))
    map_path=episode/'assets'/runtime.get('map','UNKNOWN')
    map_evidence=dict(path=str(map_path),exists=map_path.is_file(),sha256=digest(map_path) if map_path.is_file() else 'UNKNOWN')
    m=dict(schemaVersion=1,evidenceScope='ISOLATED_NATIVE_COMPLETED_LIMITED_BUDGET_REPORT_NOT_COMPLETE_MATCH',
           source=str(path),sha256=battle['sha256'],bytes=path.stat().st_size,lines=line_count,
           runtimeSource=str(episode/'runtime.json'),runtimeSha256=digest(episode/'runtime.json'),runtime=runtime,
           mapArtifact=map_evidence,provenance=provenance,battleConfig=config,
           initialPlayer=first_state.get('player'),mapDimensions=first_state.get('map'),
           summary=summary,lossesByType=dict(losses),spendByCategory=dict(spends),
           mineSelectedByProduct=dict(collections.Counter(d['product'] for d in allocations)),
           mineObservedByProduct=dict(collections.Counter(d['product'] for d in upgrades)),
           mineAllocations=allocations,mineUpgradeObservations=upgrades,
           crisisSizes=dict(minimum=min(crisis_sizes) if crisis_sizes else None,maximum=max(crisis_sizes) if crisis_sizes else None),
           maximumSimultaneousCohorts=maxcohorts,serialCohortIds=sorted(serial),supportTransfers=transfers,
           firstJetQueries=first_queries,jetQueryReasons=[dict(unitId=k[0],reason=k[1],compatibility=k[2],targetVisible=k[3],count=v) for k,v in query_reasons.items()],
           eventCounts=dict(counts),feedbackMetrics=battle['feedback']['metrics'],
           diagnosticAcceptedAgeSamples=len(age_samples),diagnosticAcceptedAgeUnknown=diag_unknown,
           longestDiagnosticAcceptedAgeSeconds=max(age_samples) if age_samples else None,
           longestSampledNoOrderAcceptedAgeSeconds=max(noorder_ages) if noorder_ages else None,
           endCredits=last_state.get('player',{}).get('credits'),
           auditResults=[dict(file=Path(r['file']).name,feedback=r['feedback']['status'],operations=r['operations']['status'],
                              operationsGaps=r['operations']['evidenceGaps'],globalPass=r['globalStrategy']['pass'],
                              specialistPass=r['specialist']['newPolicyConformancePassed'],parsed=r['parsed']['classification'],
                              parseIssues=r['parsed']['issues']) for r in all_audits],
           limitations=['PARTIAL/ONGOING budget sample is not a victory, complete match or desktop acceptance.',
                        'Seed value is recorded but deterministic seed reproducibility has not been verified.',
                        'No matched-run or causal economy/combat benefit comparison with the old desktop team5 report.',
                        'When all diagnostic accepted ages are null, tool initialization zero is not a measured idle duration.',
                        'NOT_TRIGGERED fairness/T3/Dive branches are covered only by explicit HTTP/pure fixtures when available.'])
    (out/'metrics-final.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    s=summary; fm=m['feedbackMetrics']
    text=f'''# {name} 隔离原生证据（2026-10-01）

原始报告 `{path}`，SHA-256 `{m['sha256']}`，{m['bytes']} bytes / {line_count} 行。原始文件未修改。候选 JAR `{provenance.get('agentJarSha256')}`。

本局 `{s.get('outcome')}/{s.get('matchOutcome')}`，对战游戏时间 {s.get('battleGameTimeMs',0)/1000:.3f} 秒；报告完成表示达到运行预算，不表示整局结算或胜利。运行设置依据 `runtime.json`：map={runtime.get('map')}，AI difficulty={runtime.get('aiDifficulty')}，requested speed={runtime.get('requestedSpeed')}，seed={runtime.get('seed')}，seed 可复现性未验证。无需推断旧桌面局未知设置。

| 自然行为 | 实际计数 / 边界 |
| --- | --- |
| T2 / T3 selected | {m['mineSelectedByProduct'].get('extractorT2',0)} / {m['mineSelectedByProduct'].get('extractorT3',0)} |
| T2 / T3 observed ready | {m['mineObservedByProduct'].get('extractorT2',0)} / {m['mineObservedByProduct'].get('extractorT3',0)} |
| 危机开始 / 接受响应 / 接受撤回 | {fm['crisisStarted']} / {fm['crisisRespondOrders']} / {fm['crisisReturnOrders']} |
| 响应小队人数 | {m['crisisSizes']} |
| provider jet 下单 / ready / need 转交 | {fm['providerJetConstructions']} / {fm['observedSupportJets']} / {fm['supportTransfers']} |
| Dive accepted / current compatible observed / jet response | {fm['acceptedDiveModes']} / {fm['observedCompatibleDiveModes']} / {fm['jetResponseOrders']} |
| 同时 cohort 上限 / cohort accepted order / fairness grant | {maxcohorts} / {counts['local_army_order']} / {fm['fairnessSlots']} |
| 诊断总数 / 有 accepted age 样本 | {fm['cohortDiagnostics']} / {len(age_samples)} |
| 最长诊断 accepted age / 空订单样本 age（秒） | {m['longestDiagnosticAcceptedAgeSeconds']} / {m['longestSampledNoOrderAcceptedAgeSeconds']} |
| 己方观察损失 / 末现金 | {s.get('ownLosses')} / {m['endCredits']} |

五项审计分别保存在 `suite-final.json`，四报告 feedback/operations/global/specialist 均检查各自约束；parser 为前三阶段 PASS、battle PARTIAL，无解析完整性异常。Operations 的新矿 deferral 仅检查 schema，明确把回本/安静窗/预留校验委托给 feedback audit；该局反馈审计的 triggered branches 没有 missing evidence。未触发分支不作为自然通过。

计数为零或 null 的实际含义：没有本队 accepted order 时 `lastAcceptedAgeMs` 可以为 null；初始化零不等于实测零空闲。单 cohort 不能证明多军队公平改善。隐藏潜艇目标返回 UNKNOWN/TARGET_NOT_CURRENTLY_VISIBLE 时不 Dive/attack 是观察边界，不能宣称自然反潜全链通过。相应完整链和 T3/fairness 见 `full-http-audit/SUMMARY.json` 的具体 fixture。

所有价格来自当局 native menu，回本属于披露的收入估计及预算窗；不预测未来存活。损失事件不归因到具体敌人。末现金和旧桌面局没有相同队伍/设置控制，不能声称现金或胜率因果改善。
'''
    (out/'NATIVE_SUMMARY.md').write_text(text,encoding='utf-8')
    print(json.dumps(dict(name=name,sha256=m['sha256'],feedbackMetrics=fm,mineSelected=m['mineSelectedByProduct'],mineObserved=m['mineObservedByProduct'],
                         cohorts=maxcohorts,ages=len(age_samples),losses=summary.get('ownLosses'),credits=m['endCredits'],audits=m['auditResults']),ensure_ascii=False))


if __name__=='__main__':
    run('spain','run-20261001T073550-151146')
    run('big-island','run-20261001T075134-711ad7')
