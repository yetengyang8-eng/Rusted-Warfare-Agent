"""Read-only audit of finalized HTTP evidence; reconstructed surplus remains labelled."""
import collections
import hashlib
import json
from pathlib import Path
import sys

REPO=Path(r'G:\deepseek 工作台\GitHub发布\Rusted-Warfare-Agent')
ROOT=Path(r'G:\deepseek 工作台\_validation\feedback-20261001')
sys.path.insert(0,str(REPO/'tools'))
from audit_feedback_progress import audit as feedback
from audit_operations import audit as operations
from audit_global_strategy import audit as global_strategy
from audit_specialist_lifecycle import audit as specialist
from analyze_reports import analyze_file


def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def run():
    inputs=ROOT/'full-http'
    out=ROOT/'full-http-audit'
    out.mkdir(exist_ok=True)
    sources=[]
    for family in ('local-army','provider'):
        for path in sorted((inputs/family).rglob('*.jsonl')):
            sources.append(dict(family=family,path=path,source=path,origin='ORIGINAL_FINAL_HTTP_JSONL'))
    for source in sorted((inputs/'surplus').glob('*.json')):
        data=json.loads(source.read_text(encoding='utf-8'))
        if 'events' not in data:continue
        path=out/'reconstructed-surplus'/(source.stem+'.jsonl')
        path.parent.mkdir(exist_ok=True)
        path.write_text(''.join(json.dumps(row,ensure_ascii=False)+'\n' for row in data['events']),encoding='utf-8')
        sources.append(dict(family='surplus',path=path,source=source,origin='RECONSTRUCTED_FROM_RECORDED_FIXTURE_EVENTS_NOT_ORIGINAL_RAW'))
    reports=[]
    for source in sources:
        path=source['path']
        key=source['family']+'-'+(path.parent.name if source['family']=='local-army' else path.stem)
        audits={}
        for name,func in [('feedback',feedback),('operations',operations),('global',global_strategy),('specialist',specialist),('parsed',analyze_file)]:
            try:audits[name]=func(path)
            except Exception as error:audits[name]=dict(status='EXCEPTION',exception=type(error).__name__,message=str(error))
        record=dict(schemaVersion=1,evidenceOrigin=source['origin'],fixtureSource=str(source['source']),
                    fixtureSourceSha256=digest(source['source']),auditedSource=str(path),auditedSourceSha256=digest(path),audits=audits)
        target=out/(key+'.json')
        target.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        row=dict(family=source['family'],case=key,evidenceOrigin=source['origin'],source=str(source['source']),
                 sourceSha256=record['fixtureSourceSha256'],auditArtifact=str(target),
                 feedback=audits['feedback'].get('status'),feedbackViolations=audits['feedback'].get('violationCounts'),
                 feedbackGaps=audits['feedback'].get('evidenceGaps'),feedbackCoverage=audits['feedback'].get('coverage'),
                 feedbackMetrics=audits['feedback'].get('metrics'),
                 operations=audits['operations'].get('status'),operationsViolations=audits['operations'].get('violationCounts'),
                 operationsGaps=audits['operations'].get('evidenceGaps'),
                 globalPass=audits['global'].get('pass'),globalViolations=audits['global'].get('violations'),
                 specialistPass=audits['specialist'].get('newPolicyConformancePassed'),
                 specialistViolations=audits['specialist'].get('newPolicyViolationsByReason'),
                 parsed=audits['parsed'].get('classification'),parseIssues=audits['parsed'].get('issues'))
        reports.append(row)
        print(json.dumps({k:row[k] for k in ('case','feedback','operations','globalPass','specialistPass','parsed')},ensure_ascii=False))
    totals=dict(reports=len(reports),families=dict(collections.Counter(r['family'] for r in reports)),
                feedback=dict(collections.Counter(r['feedback'] for r in reports)),
                operations=dict(collections.Counter(r['operations'] for r in reports)),
                globalStrategy=dict(collections.Counter(str(r['globalPass']) for r in reports)),
                specialist=dict(collections.Counter(str(r['specialistPass']) for r in reports)),
                parsed=dict(collections.Counter(r['parsed'] for r in reports)))
    result=dict(schemaVersion=1,scope='FINAL_HTTP_CONTRACT_FIXTURES_NOT_NATIVE_MATCH_OR_DESKTOP_ACCEPTANCE',
                totals=totals,reports=reports,
                limitations=['Surplus reconstructed JSONL is derived from recorded fixture events; source JSON and derived stream hashes are both retained.',
                             'Each audit has its own scope; NOT_TRIGGERED branches and evidence gaps remain explicit.',
                             'No kill, win-rate, desktop acceptance, or matched-control causal claim.'])
    (out/'SUMMARY.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(totals,ensure_ascii=False))


if __name__=='__main__':run()
