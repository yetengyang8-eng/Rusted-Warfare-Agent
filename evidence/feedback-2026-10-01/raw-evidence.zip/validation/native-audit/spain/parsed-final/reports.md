# 铁锈战争 Agent 离线报告汇总

结果由事件核对。INVALID 表示报告不完整或计数异常，即使原始 outcome 为 PASS 也不计入通过。

| 报告 | 版本 | 任务 | 判定 | 现实秒数 | 指令 | 观察 | 新矿 | 新厂 | 新坦克 | 建矿时完成坦克 |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| battle-1790840173749-2178e924.jsonl | 0.07-alpha1 | battle | PARTIAL | 500.276 | 618 | 877 | 11 | 2 | 0 | 0 |
| bootstrap-1790840152686-bdf42005.jsonl | 0.07-alpha1 | bootstrap | PASS | 2.272 | 1 | 7 | 0 | 0 | 0 | 0 |
| development-1790840161076-3b59c48f.jsonl | 0.07-alpha1 | development | PASS | 12.662 | 7 | 27 | 1 | 0 | 6 | 2 |
| economy-1790840155257-4f893af0.jsonl | 0.07-alpha1 | economy | PASS | 5.812 | 2 | 14 | 0 | 1 | 1 | 0 |

现实耗时从首个有效事件到最后一个有效事件计算，不是游戏内时间。建矿出兵重叠仅指日志观察区间：同一矿的 extractor_started 到 extractor_completed 之间出现 tank_completed；不等于性能或胜率证明。

| 对战报告 | 原生结算 | 对战游戏秒数 | 新观察战斗单位 | 己方损失 | 已确认进攻指令 | 工厂升级 |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| battle-1790840173749-2178e924.jsonl | ONGOING | 2401.328 | 174 | 208 | 229 | 4 |

对战 PASS 只表示已观察到原生结算。VICTORY 才是获胜；DEFEAT 是完整败局；PARTIAL 是仍在进行的限时样本。

## battle-1790840173749-2178e924.jsonl

**阶段** battle；**扩张** —

Game-time budget reached without native result

原始 summary

```json
{
  "outcome": "PARTIAL",
  "reason": "Game-time budget reached without native result",
  "phase": "battle",
  "matchOutcome": "ONGOING",
  "commands": 618,
  "observations": 877,
  "ownLosses": 208,
  "newCombatUnits": 174,
  "attackOrders": 231,
  "attackOrdersConfirmed": 229,
  "retreatOrders": 83,
  "upgradesCompleted": 4,
  "completedMines": 11,
  "newMines": 11,
  "mineTarget": 3,
  "minesBeyondFloor": 2,
  "expansionRefusals": 44,
  "expansionBlocked": 137,
  "completedFactories": 2,
  "newFactories": 2,
  "landFactoryTarget": 3,
  "factoryBlocks": 0,
  "builderTarget": 1,
  "builderRecoveries": 15,
  "builderOrders": 15,
  "battleGameTimeMs": 2401328,
  "gameSecondsPerWallSecond": 4.8,
  "noProgressWindowMs": 20000,
  "noProgressCooldownMs": 30000,
  "targetNoProgressTriggers": 1,
  "targetRetries": 1,
  "targetSuppressionsStarted": 16,
  "targetSuppressionsReleased": 4,
  "targetSuppressedSelections": 40,
  "targetSuppressionsAtEnd": 12,
  "targetSwitches": 134,
  "effectiveDecisionIntervalGameMs": 2784,
  "noProgressAttentionGapMs": 8352,
  "maxObservedGameTimeJump": 3216,
  "observationCount": 877,
  "spendTotal": 156150,
  "spendByCategory": {
    "FACTORY_UPGRADE": {
      "orders": 4,
      "cost": 8000
    },
    "NEW_MINE": {
      "orders": 14,
      "cost": 9800
    },
    "UNIT_PRODUCTION": {
      "orders": 174,
      "cost": 104550
    },
    "MINE_UPGRADE": {
      "orders": 2,
      "cost": 2800
    },
    "STRATEGIC_CAPABILITY": {
      "orders": 4,
      "cost": 8000
    },
    "NEW_FACTORY": {
      "orders": 2,
      "cost": 1400
    },
    "STRATEGIC_CONSTRUCTION": {
      "orders": 9,
      "cost": 14100
    },
    "BUILDER_RECOVERY": {
      "orders": 15,
      "cost": 7500
    }
  },
  "measuredIncomePerGameSecond": 64.0,
  "investmentIntentions": 0,
  "investmentCompletions": 0,
  "investmentCancellations": 0,
  "investmentReserveAtEnd": 0,
  "investmentPendingAtEnd": false,
  "finalUrgency": "EMERGENCY",
  "reconEnabled": true,
  "reconTasksCreated": 12,
  "reconOrdersQueued": 20,
  "reconOrdersObserved": 15,
  "reconMovesCompletedBetweenSamples": 5,
  "frontierTasksSatisfiedByTeamVision": 1,
  "reconResolvedAfterObservedMove": 3,
  "reconReacquired": 6,
  "reconSitesCleared": 0,
  "reconBlocked": 2,
  "reconTaskPendingAtEnd": true,
  "reconFrontierEnabled": true,
  "frontierTasksCreated": 3,
  "frontierTasksRefreshed": 0,
  "frontierTasksAdvanced": 0,
  "frontierTasksBlocked": 1,
  "frontierTasksPreempted": 1,
  "expendableTransfers": 2,
  "expendableScoutsAtEnd": 0,
  "factoryTargetIncreases": 1,
  "factoryTargetIncreaseBlocks": 2,
  "landFactoryTargetAtEnd": 3,
  "factoryTargetCommittedAtEnd": false,
  "landFactoryTargetMax": 5,
  "factorySaturationPct": 20.22,
  "factorySaturationMinPct": 80,
  "economyBaseIncome": 26.9,
  "economyIncomePerMine": 12.07,
  "economyModelSource": "MEASURED_4_MATCHES_2_SPEEDS_T1_R2_0.999_T2_T3_ESTIMATED_FROM_FROZEN_GENERATION_RATIOS",
  "minesReadyAtEnd": 2,
  "productionConsumptionPerGameSecond": 31.3,
  "sustainableSurplusPerGameSecond": 19.7,
  "strategy": {
    "enabled": true,
    "armyTarget": 32,
    "activeTarget": 24,
    "reserveTarget": 8,
    "hardSafetyCap": 128,
    "builderTarget": 1,
    "capabilityNeedsAtEnd": 12,
    "needsResolvedByLegalEvidence": 0,
    "investmentOrders": 15,
    "mineUpgradesObserved": 2,
    "constructionCompletionsObserved": 9,
    "capabilityReservesStarted": 2,
    "capabilityReservesReleased": 2,
    "capabilityReserveAtEnd": 0.0
  }
}
```

## bootstrap-1790840152686-bdf42005.jsonl

**阶段** ready_preflight；**扩张** —

Completed own builder available; fresh preflight permits Match

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "Completed own builder available; fresh preflight permits Match",
  "phase": "ready_preflight",
  "bootstrapMode": "AUTOMATIC_NATIVE_PRODUCTION",
  "commands": 1,
  "automaticProductionCommands": 1,
  "observations": 7,
  "queueObserved": true,
  "producerId": 477,
  "builderId": 568,
  "resolvedBuilderType": "builder",
  "completionEvidence": "NEW_OWN_UNIT_AND_NATIVE_QUEUE_CYCLE",
  "gameBudgetSeconds": 180,
  "wallBudgetSeconds": 120
}
```

## development-1790840161076-3b59c48f.jsonl

**阶段** tank_observe；**扩张** LIMIT_REACHED

Tank target completed; mines 1/1; expansion LIMIT_REACHED; all task units alive

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "Tank target completed; mines 1/1; expansion LIMIT_REACHED; all task units alive",
  "phase": "tank_observe",
  "commands": 7,
  "observations": 27,
  "completedMines": 1,
  "completedTanks": 6,
  "expansionStatus": "LIMIT_REACHED",
  "scoutMoves": 0,
  "scoutArrivals": 0,
  "scoutBlocked": 0,
  "scoutedMines": 0,
  "scoutRetreats": 0,
  "escortsAssigned": 0,
  "escortsConfirmed": 0,
  "newlyExploredTiles": 0
}
```

## economy-1790840155257-4f893af0.jsonl

**阶段** tank_1_produce；**扩张** —

New landFactory completed; its queue was observed active then empty; one new own tank appeared nearby

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "New landFactory completed; its queue was observed active then empty; one new own tank appeared nearby",
  "phase": "tank_1_produce",
  "commands": 2,
  "observations": 14,
  "completedBuildings": 1,
  "completedTanks": 1
}
```
