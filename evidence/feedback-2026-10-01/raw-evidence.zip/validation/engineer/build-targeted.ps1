$ErrorActionPreference='Stop'
$repo='G:\deepseek 工作台\_validation\feedback-20261001\engineer'
$taskRoot='G:\deepseek 工作台\_validation\feedback-20261001\engineer'
$java='C:\Program Files\BellSoft\LibericaJDK-17\bin\java.exe'
$game='G:\deepseek 工作台\游戏环境\rustedwarfare PC 1.15 原版\game-lib.jar'
$classes=Join-Path $taskRoot 'classes'
$tests=Join-Path $taskRoot 'tests'
New-Item -ItemType Directory -Force -Path $classes,$tests | Out-Null
$files=Get-ChildItem -Recurse -LiteralPath (Join-Path $repo 'agent\src') -Filter '*.java' | ForEach-Object FullName
& $java -m jdk.compiler/com.sun.tools.javac.Main --release 8 -encoding UTF-8 -cp $game -d $classes $files
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
$jar=Join-Path $taskRoot 'engineer.jar'
& $java -m jdk.jartool/sun.tools.jar.Main --create --file $jar --manifest (Join-Path $repo 'agent\MANIFEST.MF') -C $classes . -C (Join-Path $repo 'agent\resources') .
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
$testFiles=Get-ChildItem -LiteralPath (Join-Path $repo 'agent\tests') -Filter '*.java' | ForEach-Object FullName
& $java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -cp "$game;G:\deepseek 工作台\游戏环境\rustedwarfare PC 1.15 原版\libs\*;$jar" -d $tests $testFiles
exit $LASTEXITCODE

