from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

WORKSPACE = Path(r'G:\deepseek 工作台')
REPO = WORKSPACE / 'GitHub发布/Rusted-Warfare-Agent'
TASK = WORKSPACE / '_validation/feedback-20261001'
EVIDENCE = REPO / 'evidence/feedback-2026-10-01'
DELIVERY = REPO / 'deliveries/feedback-2026-10-01'
PYTHON = r'C:\Users\Administrator\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


# Preserve launcher content while ensuring the new delivery uses Windows line endings.
for launcher in DELIVERY.glob('*.bat'):
    text = launcher.read_text(encoding='utf-8')
    launcher.write_bytes(text.replace('\r\n', '\n').replace('\n', '\r\n').encode('utf-8'))

copies = {
    'INPUT_ANALYSIS.md': 'INPUT_ANALYSIS.md',
    'metrics.json': 'metrics.json',
    'CRISIS_IMPLEMENTATION.md': 'CRISIS_IMPLEMENTATION.md',
    'engineer/ENGINEER_PROVIDER_NOTES.md': 'ENGINEER_PROVIDER_NOTES.md',
    'candidate-identity.json': 'candidate-identity.json',
    'source-candidate-comparison.json': 'source-candidate-comparison.json',
    'validation-summary.json': 'validation-summary.json',
    'first-matrix.json': 'first-matrix.json',
    'starting-baseline-verification.json': 'starting-baseline-verification.json',
    'final-baseline-verification.json': 'final-baseline-verification.json',
    'full-http-audit/SUMMARY.md': 'HTTP_SUMMARY.md',
    'full-http-audit/SUMMARY.json': 'HTTP_SUMMARY.json',
    'native-audit/spain/NATIVE_SUMMARY.md': 'SPAIN_NATIVE_SUMMARY.md',
    'native-audit/spain/metrics-final.json': 'spain-metrics.json',
    'native-audit/spain/suite-final.json': 'spain-audit-suite.json',
    'native-audit/big-island/NATIVE_SUMMARY.md': 'BIG_ISLAND_NATIVE_SUMMARY.md',
    'native-audit/big-island/metrics-final.json': 'big-island-metrics.json',
    'native-audit/big-island/suite-final.json': 'big-island-audit-suite.json',
}
for origin, destination in copies.items():
    shutil.copyfile(TASK / origin, EVIDENCE / destination)

sources = {}


def include(path, archive_name=None):
    if not path.is_file():
        return
    name = archive_name or 'validation/' + path.relative_to(TASK).as_posix()
    assert name not in sources or sources[name] == path, name
    sources[name] = path


def include_tree(relative):
    root = TASK / relative
    for path in root.rglob('*'):
        if path.suffix.lower() in {'.json', '.jsonl', '.log', '.md', '.txt', '.py', '.ps1'}:
            if '__pycache__' not in path.parts:
                include(path)


# Explicit result directories; never traverse resource copies or full episode trees.
for relative in [
    'full-http', 'full-http-audit', 'native-audit', 'audit-targeted',
    'old-mine-control', 'crisis/logs', 'engineer/http-first',
    'engineer/http-final', 'engineer/http-fresh-commit', 'engineer/specialist-final',
    'combined-targeted/mine-http', 'combined-targeted-fixed/mine-http',
    'source/agent/build/logs',
]:
    include_tree(relative)
for relative in ['crisis', 'engineer', 'combined-targeted', 'combined-targeted-fixed', 'source']:
    for path in (TASK / relative).glob('*'):
        if path.suffix.lower() in {'.json', '.log', '.md', '.txt', '.py', '.ps1'}:
            include(path)
for path in TASK.glob('*'):
    if path.suffix.lower() in {'.json', '.log', '.md', '.txt', '.py'}:
        include(path)

native_contexts = []
for folder in ['native-spain', 'native-big-island']:
    runs = list((TASK / folder).glob('run-*'))
    assert len(runs) == 1
    run = runs[0]
    episode = run / 'episode-001'
    for path in run.glob('*.json'):
        include(path)
    for path in episode.glob('*'):
        if path.suffix.lower() in {'.json', '.log'}:
            include(path)
    for path in (episode / 'rw-agent-reports').glob('*'):
        if path.suffix.lower() in {'.json', '.jsonl'}:
            include(path)
    claims = read(run / 'live-claims.json')
    assert all(item['state'] == 'EXITED' for item in claims['processes'])
    battle = list((episode / 'rw-agent-reports').glob('battle-*.jsonl'))
    assert len(battle) == 1
    native_contexts.append({
        'name': folder, 'actualRunDirectory': str(run),
        'runtime': read(episode / 'runtime.json'),
        'battleRaw': str(battle[0]), 'battleSha256': sha(battle[0]),
        'candidateJarSha256': sha(episode / 'rw-agent-bootstrap.jar'),
        'allOwnedTestProcessesRecordedExited': True,
        'result': 'PARTIAL', 'outcome': 'ONGOING',
        'originalRunnerFailurePreserved': True,
        'finalOfflineParserIntegrityIssues': [],
    })

feedback = Path(r'C:\Users\Administrator\Desktop\反馈.txt')
assert sha(feedback) == '1fae7d027d58cd51f67283751262d17a29c0f7af963a65ada9d947ea6bfbe13e'
include(feedback, 'inputs/feedback-original.txt')
architecture = list(feedback.parent.glob('*思维架构*4.txt'))
if len(architecture) == 1:
    include(architecture[0], 'inputs/architecture-v4-original.txt')
include(EVIDENCE / 'mine-mechanism-sources.json', 'identity/mine-mechanism-sources.json')

identity = read(TASK / 'candidate-identity.json')
expected_jar = identity['agentJarSha256']
assert sha(DELIVERY / 'rw-agent-bootstrap.jar') == expected_jar
assert sha(TASK / 'fixed-candidate/rw-agent-bootstrap.jar') == expected_jar
assert all(item['candidateJarSha256'] == expected_jar for item in native_contexts)
comparison = read(TASK / 'source-candidate-comparison.json')
assert comparison['passed'] and len(comparison['files']) == 32
for item in comparison['files']:
    assert item['same'] and sha(REPO / item['path']) == item['sha256']
for name in ['starting-baseline-verification.json', 'final-baseline-verification.json']:
    baseline = read(TASK / name)
    assert baseline['filesChecked'] == 106
    assert {item['kind'] for item in baseline['failures']} == {'source_drift'}
matrix = read(TASK / 'validation-summary.json')
assert matrix['effectiveMatrix']['failedSteps'] == 0
assert matrix['effectiveMatrix']['distinctPythonTests'] == 420
assert sum(item['pythonTests'] or 0 for item in matrix['steps']) == 420
for folder in ['spain', 'big-island']:
    suite = read(TASK / f'native-audit/{folder}/suite-final.json')
    assert len(suite['reports']) == 4
    for report in suite['reports']:
        assert report['feedback']['status'] == report['operations']['status'] == 'PASS'
        assert report['globalStrategy']['pass'] and not report['globalStrategy']['violations']
        assert report['specialist']['newPolicyConformancePassed']
        assert not report['specialist']['newPolicyViolations']
        assert report['parsed']['result'] in {'PASS', 'PARTIAL'} and not report['parsed']['issues']

raw_index = {
    'schemaVersion': 1, 'candidateId': identity['candidateId'],
    'commercialAssetsExcluded': True, 'playerPreferencesSavesCachesExcluded': True,
    'inputDesktopRawIncluded': False,
    'inputDesktopRawProvenance': 'INPUT_ANALYSIS.md and metrics.json; source path, SHA and line numbers retained',
    'selection': 'Explicit reports/logs/audits/contract fixtures, failures and provenance. No game-lib/JAR/assets/maps/libs/res or isolated player state.',
    'files': [
        {'entry': name, 'origin': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}
        for name, path in sorted(sources.items())
    ],
}
zip_path = EVIDENCE / 'raw-evidence.zip'
with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for item in raw_index['files']:
        entry = item['entry']
        path = sources[entry]
        assert not any(part in {'assets', 'libs', 'res', 'saves', '__pycache__'} for part in Path(entry).parts)
        assert path.suffix.lower() not in {'.jar', '.class', '.ini', '.rwsave', '.replay', '.tmx'}
        archive.write(path, entry)
with zipfile.ZipFile(zip_path) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(raw_index['files'])
    for item in raw_index['files']:
        assert hashlib.sha256(archive.read(item['entry'])).hexdigest() == item['sha256']
raw_index['archive'] = {'file': 'raw-evidence.zip', 'bytes': zip_path.stat().st_size, 'sha256': sha(zip_path)}
write(EVIDENCE / 'raw-evidence-index.json', raw_index)

manifest = {
    'schemaVersion': 1, 'candidateId': identity['candidateId'],
    'date': '2026-10-01', 'timezone': 'Asia/Shanghai',
    'frozenBaselineId': 'RW-BASELINE-2026-09-30-GS-v1', 'baselinePromoted': False,
    'inputCommit': identity['baseCommit'],
    'implementationCommit': comparison['implementationCommit'],
    'auditCommit': matrix['auditCommit'],
    'documentationCommit': 'Read repository HEAD; documentation commit is not the JAR compilation input',
    'agentJar': {key: identity[key] for key in ['agentJarSha256', 'agentJarBytes', 'contentDigest', 'nonManifestEntries']},
    'jarEntryIdentity': 'candidate-identity.json',
    'productionSourceExactComparison': {'passed': True, 'files': 32, 'evidence': 'source-candidate-comparison.json'},
    'gameLibSha256': '8a550a37e2d8a5430866090d4e7d5892f9010b47f52a5a09350fc66c620deec9',
    'catalogSha256': '263cdaaa3e923e8307c37f059e50bee529b8ecd7c3e215937ce2adf615a0e236',
    'regression': matrix['effectiveMatrix'], 'originalFullRun': matrix['firstFullRun'],
    'regressionMethod': matrix['method'],
    'finalHttpFixtures': {'army': 14, 'provider': 8, 'surplus': 11, 'total': 33, 'auditKindsPerFixture': 5, 'violations': 0},
    'nativeRuns': native_contexts,
    'naturalDiveEvidence': {'accepted': 3, 'uniqueResponders': 1, 'unitId': 1241, 'rawLines': [6625, 8756, 10421], 'observedMovementType': 'WATER', 'observedWeaponRange': 100},
    'spainMap': {
        'actualSource': str(WORKSPACE / '游戏环境/P1F-GPTSol61-Operations-2026-10-01/mods/maps/[10p] 10p 西班牙混战_by_MP97.tmx'),
        'sha256': '342db6d8a8b8320b6a271b9e3c8a4c29c96a203e206c4be690c44bbef5882746',
        'bytes': 365704, 'width': 400, 'height': 370, 'modified': False,
        'nativeCopyOnly': True, 'provesInputDesktopUsedThisMap': False,
    },
    'deliveryFiles': [
        {'file': path.name, 'bytes': path.stat().st_size, 'sha256': sha(path)}
        for path in sorted(DELIVERY.iterdir()) if path.is_file()
    ],
    'evidenceArchive': raw_index['archive'], 'rawIndex': 'raw-evidence-index.json',
    'desktopInstalledByThisTask': False, 'userDesktopGameStartedOrClosed': False,
    'verifiedNaturalOutcome': 'Two budget-limited PARTIAL/ONGOING samples; no native final result',
    'unimplemented': ['local new-site expansion', 'early multi-direction recoverable tank probes', 'mammoth spending', 'generic engineer heavy reinforcement', 'continuous all-cohort HP/no-progress observation independent of actuator'],
    'limitations': ['No desktop acceptance or win-rate causal evidence', 'Spain hidden targets did not naturally trigger Dive', 'Big Island 3 Dive chains reuse 1 responder, not 3 independent products', 'Mode completion mainly uses current target engagement; own mode and changed target domain joint confirmation still needed', 'Ready matching is unique role/site/time evidence, not strict producer birth lineage', 'Big Island accepted age crosses inactive mode and is not whole-cohort idle', 'seed repeatability unverified', 'new candidate 4800 natural run not executed'],
}
write(EVIDENCE / 'candidate-manifest.json', manifest)

# Synchronize the authoritative handoff with absolute targets for the external copy.
handoff = REPO / 'handoff/HANDOFF_Codex_Feedback_2026-10-01.md'
content = handoff.read_text('utf-8')
def absolute_link(match):
    label, target = match.groups()
    if '://' in target or target.startswith('#'):
        return match.group(0)
    resolved = (handoff.parent / target).resolve()
    assert resolved.is_file(), str(resolved)
    return f'[{label}](<{resolved.as_posix()}>)'
external = WORKSPACE / '助手交接/HANDOFF_Codex_Feedback_2026-10-01.md'
external.write_text(re.sub(r'\[([^\]]+)\]\(([^)]+)\)', absolute_link, content), 'utf-8')

for path in [WORKSPACE / 'CURRENT_STATE.md', WORKSPACE / 'HANDOFF_FOR_CODEX.md', REPO / 'project-state/HANDOFF_FOR_CODEX.md']:
    text = path.read_text('utf-8')
    text = text.replace('HANDOFF_Codex_Operations_2026-10-01.md', 'HANDOFF_Codex_Feedback_2026-10-01.md')
    text = text.replace('2026-10-01运营与队伍调动', '2026-10-01反馈驱动的运营与调度')
    if path.name == 'HANDOFF_FOR_CODEX.md':
        text = text.replace('无builder起步、多队控制和富余资金支出已落在当前仓库', '无builder起步、多队控制、局部危机、公平调度、后方生产与T2/T3局部投资已落在当前仓库')
        text = text.replace('无builder起步、多队控制、富余支出及4800入口以此和仓库CURRENT_STATE为准。', '自动起步、局部危机、公平调度、后方生产、T2/T3投资及4800入口以此和仓库CURRENT_STATE为准。')
    path.write_text(text, 'utf-8')

write(EVIDENCE / 'delivery-verification.json', {
    'schemaVersion': 1, 'candidateId': identity['candidateId'],
    'candidateJarMatchesFixedAndBothNativeRuns': True,
    'productionSourceMatchesCompiledSnapshotFiles': 32,
    'archiveEntriesVerifiedAgainstSha256': len(raw_index['files']),
    'commercialAssetsAndPlayerStateExcluded': True,
    'baselineProtectedFilesVerified': 106,
    'finalNativeReportsAudited': 8,
    'finalNativeFiveAuditAssertionsPassed': True,
    'expectedSourceDriftOnly': True,
    'externalHandoffSynchronizedWithAbsoluteLinks': str(external),
    'archive': raw_index['archive'],
})
print(json.dumps({'archiveFiles': len(raw_index['files']), 'archiveBytes': zip_path.stat().st_size,
                  'archiveSha256': sha(zip_path), 'jarSha256': expected_jar,
                  'handoff': str(external)}, ensure_ascii=False))
