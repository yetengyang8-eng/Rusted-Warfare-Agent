# 铁锈战争 Agent 离线报告汇总

结果由事件核对。INVALID 表示报告不完整或计数异常，即使原始 outcome 为 PASS 也不计入通过。

| 报告 | 版本 | 任务 | 判定 | 现实秒数 | 指令 | 观察 | 新矿 | 新厂 | 新坦克 | 建矿时完成坦克 |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| battle-1790694969948-06fe23c2.jsonl | 0.07-alpha1 | battle | PASS | 663.877 | 275 | 1284 | 3 | 2 | 0 | 0 |
| battle-1790695718778-c223b78f.jsonl | 0.07-alpha1 | battle | PARTIAL | 360.408 | 409 | 691 | 11 | 1 | 0 | 0 |
| development-1790694917469-f5ad892b.jsonl | 0.07-alpha1 | development | PASS | 52.462 | 7 | 105 | 1 | 0 | 6 | 2 |
| development-1790695706430-dedeaddc.jsonl | 0.07-alpha1 | development | PASS | 12.331 | 7 | 27 | 1 | 0 | 6 | 2 |
| economy-1790694890326-3e05bd66.jsonl | 0.07-alpha1 | economy | PASS | 26.814 | 2 | 55 | 0 | 1 | 1 | 0 |
| economy-1790695696331-b010120c.jsonl | 0.07-alpha1 | economy | PASS | 9.797 | 2 | 22 | 0 | 1 | 1 | 0 |

现实耗时从首个有效事件到最后一个有效事件计算，不是游戏内时间。建矿出兵重叠仅指日志观察区间：同一矿的 extractor_started 到 extractor_completed 之间出现 tank_completed；不等于性能或胜率证明。

| 对战报告 | 原生结算 | 对战游戏秒数 | 新观察战斗单位 | 己方损失 | 已确认进攻指令 | 工厂升级 |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| battle-1790694969948-06fe23c2.jsonl | VICTORY | 663.874 | 69 | 39 | 137 | 1 |
| battle-1790695718778-c223b78f.jsonl | ONGOING | 1802.02 | 55 | 21 | 300 | 2 |

对战 PASS 只表示已观察到原生结算。VICTORY 才是获胜；DEFEAT 是完整败局；PARTIAL 是仍在进行的限时样本。

## battle-1790694969948-06fe23c2.jsonl

**阶段** battle；**扩张** —

Native result screen: VICTORY

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "Native result screen: VICTORY",
  "phase": "battle",
  "matchOutcome": "VICTORY",
  "commands": 275,
  "observations": 1284,
  "ownLosses": 39,
  "newCombatUnits": 69,
  "attackOrders": 137,
  "attackOrdersConfirmed": 137,
  "retreatOrders": 31,
  "upgradesCompleted": 1,
  "completedMines": 3,
  "newMines": 3,
  "mineTarget": 3,
  "minesBeyondFloor": 1,
  "expansionRefusals": 32,
  "expansionBlocked": 38,
  "completedFactories": 2,
  "newFactories": 2,
  "landFactoryTarget": 3,
  "factoryBlocks": 34,
  "builderTarget": 1,
  "builderRecoveries": 0,
  "builderOrders": 0,
  "battleGameTimeMs": 663874,
  "gameSecondsPerWallSecond": 1.0,
  "noProgressWindowMs": 20000,
  "noProgressCooldownMs": 30000,
  "targetNoProgressTriggers": 0,
  "targetRetries": 0,
  "targetSwitches": 56,
  "effectiveDecisionIntervalGameMs": 1044,
  "noProgressAttentionGapMs": 3132,
  "maxObservedGameTimeJump": 570,
  "observationCount": 1284,
  "spendTotal": 42050,
  "spendByCategory": {
    "FACTORY_UPGRADE": {
      "orders": 1,
      "cost": 2000
    },
    "NEW_MINE": {
      "orders": 3,
      "cost": 2100
    },
    "UNIT_PRODUCTION": {
      "orders": 71,
      "cost": 36550
    },
    "NEW_FACTORY": {
      "orders": 2,
      "cost": 1400
    }
  },
  "measuredIncomePerGameSecond": 59.81,
  "investmentIntentions": 3,
  "investmentCompletions": 1,
  "investmentCancellations": 2,
  "investmentReserveAtEnd": 0,
  "investmentPendingAtEnd": true,
  "finalUrgency": "OPEN_EXPANSION",
  "reconEnabled": true,
  "reconTasksCreated": 11,
  "reconOrdersQueued": 11,
  "reconOrdersObserved": 10,
  "reconMovesCompletedBetweenSamples": 1,
  "frontierTasksSatisfiedByTeamVision": 1,
  "reconResolvedAfterObservedMove": 2,
  "reconReacquired": 2,
  "reconSitesCleared": 0,
  "reconBlocked": 0,
  "reconTaskPendingAtEnd": false,
  "reconFrontierEnabled": true,
  "frontierTasksCreated": 9,
  "frontierTasksRefreshed": 7,
  "frontierTasksAdvanced": 0,
  "frontierTasksBlocked": 0,
  "frontierTasksPreempted": 1,
  "expendableTransfers": 2,
  "expendableScoutsAtEnd": 1,
  "factoryTargetIncreases": 1,
  "factoryTargetIncreaseBlocks": 2,
  "landFactoryTargetAtEnd": 3,
  "factoryTargetCommittedAtEnd": false,
  "landFactoryTargetMax": 5,
  "factorySaturationPct": 41.43,
  "factorySaturationMinPct": 80,
  "economyBaseIncome": 26.9,
  "economyIncomePerMine": 12.07,
  "economyModelSource": "MEASURED_4_MATCHES_2_SPEEDS_CONSTANT_MINE_WINDOWS_R2_0.999",
  "minesReadyAtEnd": 4,
  "productionConsumptionPerGameSecond": 58.0,
  "sustainableSurplusPerGameSecond": 17.2
}
```

## battle-1790695718778-c223b78f.jsonl

**阶段** battle；**扩张** —

Game-time budget reached without native result

原始 summary

```json
{
  "outcome": "PARTIAL",
  "reason": "Game-time budget reached without native result",
  "phase": "battle",
  "matchOutcome": "ONGOING",
  "commands": 409,
  "observations": 691,
  "ownLosses": 21,
  "newCombatUnits": 55,
  "attackOrders": 301,
  "attackOrdersConfirmed": 300,
  "retreatOrders": 6,
  "upgradesCompleted": 2,
  "completedMines": 11,
  "newMines": 11,
  "mineTarget": 3,
  "minesBeyondFloor": 9,
  "expansionRefusals": 128,
  "expansionBlocked": 136,
  "completedFactories": 1,
  "newFactories": 1,
  "landFactoryTarget": 2,
  "factoryBlocks": 0,
  "builderTarget": 1,
  "builderRecoveries": 0,
  "builderOrders": 0,
  "battleGameTimeMs": 1802020,
  "gameSecondsPerWallSecond": 5.0,
  "noProgressWindowMs": 20000,
  "noProgressCooldownMs": 30000,
  "targetNoProgressTriggers": 0,
  "targetRetries": 0,
  "targetSwitches": 255,
  "effectiveDecisionIntervalGameMs": 2650,
  "noProgressAttentionGapMs": 7950,
  "maxObservedGameTimeJump": 2735,
  "observationCount": 691,
  "spendTotal": 45150,
  "spendByCategory": {
    "FACTORY_UPGRADE": {
      "orders": 2,
      "cost": 4000
    },
    "UNIT_PRODUCTION": {
      "orders": 55,
      "cost": 32750
    },
    "NEW_MINE": {
      "orders": 11,
      "cost": 7700
    },
    "NEW_FACTORY": {
      "orders": 1,
      "cost": 700
    }
  },
  "measuredIncomePerGameSecond": 124.22,
  "investmentIntentions": 13,
  "investmentCompletions": 8,
  "investmentCancellations": 5,
  "investmentReserveAtEnd": 0,
  "investmentPendingAtEnd": true,
  "finalUrgency": "OPEN_EXPANSION",
  "reconEnabled": true,
  "reconTasksCreated": 0,
  "reconOrdersQueued": 0,
  "reconOrdersObserved": 0,
  "reconMovesCompletedBetweenSamples": 0,
  "frontierTasksSatisfiedByTeamVision": 0,
  "reconResolvedAfterObservedMove": 0,
  "reconReacquired": 0,
  "reconSitesCleared": 0,
  "reconBlocked": 0,
  "reconTaskPendingAtEnd": false,
  "reconFrontierEnabled": true,
  "frontierTasksCreated": 0,
  "frontierTasksRefreshed": 0,
  "frontierTasksAdvanced": 0,
  "frontierTasksBlocked": 0,
  "frontierTasksPreempted": 0,
  "expendableTransfers": 0,
  "expendableScoutsAtEnd": 0,
  "factoryTargetIncreases": 0,
  "factoryTargetIncreaseBlocks": 1,
  "landFactoryTargetAtEnd": 2,
  "factoryTargetCommittedAtEnd": false,
  "landFactoryTargetMax": 5,
  "factorySaturationPct": 0.0,
  "factorySaturationMinPct": 80,
  "economyBaseIncome": 26.9,
  "economyIncomePerMine": 12.07,
  "economyModelSource": "MEASURED_4_MATCHES_2_SPEEDS_CONSTANT_MINE_WINDOWS_R2_0.999",
  "minesReadyAtEnd": 12,
  "productionConsumptionPerGameSecond": 0.0,
  "sustainableSurplusPerGameSecond": 171.7
}
```

## development-1790694917469-f5ad892b.jsonl

**阶段** tank_observe；**扩张** LIMIT_REACHED

Tank target completed; mines 1/1; expansion LIMIT_REACHED; all task units alive

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "Tank target completed; mines 1/1; expansion LIMIT_REACHED; all task units alive",
  "phase": "tank_observe",
  "commands": 7,
  "observations": 105,
  "completedMines": 1,
  "completedTanks": 6,
  "expansionStatus": "LIMIT_REACHED",
  "scoutMoves": 0,
  "scoutArrivals": 0,
  "scoutBlocked": 0,
  "scoutedMines": 0,
  "scoutRetreats": 0,
  "escortsAssigned": 0,
  "escortsConfirmed": 0,
  "newlyExploredTiles": 0
}
```

## development-1790695706430-dedeaddc.jsonl

**阶段** tank_observe；**扩张** LIMIT_REACHED

Tank target completed; mines 1/1; expansion LIMIT_REACHED; all task units alive

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "Tank target completed; mines 1/1; expansion LIMIT_REACHED; all task units alive",
  "phase": "tank_observe",
  "commands": 7,
  "observations": 27,
  "completedMines": 1,
  "completedTanks": 6,
  "expansionStatus": "LIMIT_REACHED",
  "scoutMoves": 0,
  "scoutArrivals": 0,
  "scoutBlocked": 0,
  "scoutedMines": 0,
  "scoutRetreats": 0,
  "escortsAssigned": 0,
  "escortsConfirmed": 0,
  "newlyExploredTiles": 0
}
```

## economy-1790694890326-3e05bd66.jsonl

**阶段** tank_1_produce；**扩张** —

New landFactory completed; its queue was observed active then empty; one new own tank appeared nearby

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "New landFactory completed; its queue was observed active then empty; one new own tank appeared nearby",
  "phase": "tank_1_produce",
  "commands": 2,
  "observations": 55,
  "completedBuildings": 1,
  "completedTanks": 1
}
```

## economy-1790695696331-b010120c.jsonl

**阶段** tank_1_produce；**扩张** —

New landFactory completed; its queue was observed active then empty; one new own tank appeared nearby

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "New landFactory completed; its queue was observed active then empty; one new own tank appeared nearby",
  "phase": "tank_1_produce",
  "commands": 2,
  "observations": 22,
  "completedBuildings": 1,
  "completedTanks": 1
}
```
