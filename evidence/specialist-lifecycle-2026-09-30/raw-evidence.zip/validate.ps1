param([ValidateSet('targeted','full')][string]$Mode='targeted')
$ErrorActionPreference='Stop'
$auditRoot=$PSScriptRoot
$sourceRoot=Join-Path $auditRoot 'source'
$repoRoot='G:\deepseek 工作台\GitHub发布\Rusted-Warfare-Agent'
$env:JAVA_HOME='C:\Program Files\BellSoft\LibericaJDK-17'
$pythonDir='C:\Users\Administrator\.cache\codex-runtimes\codex-primary-runtime\dependencies\python'
$env:PATH="$env:JAVA_HOME\bin;$pythonDir;$env:PATH"
$env:PYTHONIOENCODING='utf-8'
$env:PYTHONUTF8='1'
$env:JAVA_TOOL_OPTIONS='-Dfile.encoding=UTF-8 -Dsun.stdout.encoding=UTF-8 -Dsun.stderr.encoding=UTF-8'
$env:TEMP=Join-Path $auditRoot 'temp'
$env:TMP=$env:TEMP
New-Item -ItemType Directory -Force -Path $env:TEMP | Out-Null
$gameDir='G:\deepseek 工作台\游戏环境\rustedwarfare PC 1.15 原版'
$gameJar=Join-Path $gameDir 'game-lib.jar'
$libsDir=Join-Path $gameDir 'libs'
$agentRoot=Join-Path $sourceRoot 'agent'
$resolvedAgent=(Resolve-Path -LiteralPath $agentRoot).Path
if (-not $resolvedAgent.StartsWith((Join-Path $auditRoot 'source\'),[StringComparison]::OrdinalIgnoreCase)) { throw 'Unexpected validation path' }
$logDir=Join-Path $auditRoot $Mode
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
if ($Mode -eq 'full') {
    $env:RW_SPECIALIST_LIFECYCLE_EVIDENCE_DIR=Join-Path $logDir 'specialist-cases'
    & pwsh -NoProfile -File (Join-Path $agentRoot 'test-win.ps1') $gameJar $libsDir *> (Join-Path $logDir 'full-regression.log')
    $resultCode=$LASTEXITCODE
    Set-Content -LiteralPath (Join-Path $logDir 'exit-code.txt') -Value $resultCode -Encoding utf8
    Get-Content -LiteralPath (Join-Path $logDir 'full-regression.log') -Tail 49
    exit $resultCode
}
$classes=Join-Path $agentRoot 'build\classes'
$tests=Join-Path $agentRoot 'build\tests'
$dist=Join-Path $agentRoot 'dist'
New-Item -ItemType Directory -Force -Path $classes,$tests,$dist | Out-Null
$jar=Join-Path $dist 'rw-agent-bootstrap.jar'
$steps=[System.Collections.Generic.List[object]]::new()
function RunStep([string]$name,[scriptblock]$body) {
    & $body *> (Join-Path $logDir ($name+'.log'))
    $code=$LASTEXITCODE
    $steps.Add(@{step=$name;exitCode=$code})
    $steps | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $logDir 'steps.json') -Encoding utf8
    Write-Output "$name exit=$code"
    if ($code -ne 0) { Get-Content -LiteralPath (Join-Path $logDir ($name+'.log')) -Tail 35; exit $code }
}
RunStep 'build-compile' { $files=Get-ChildItem -LiteralPath (Join-Path $agentRoot 'src') -Recurse -Filter '*.java' | ForEach-Object FullName; & java -m jdk.compiler/com.sun.tools.javac.Main --release 8 -encoding UTF-8 -cp $gameJar -d $classes $files }
RunStep 'build-jar' { & java -m jdk.jartool/sun.tools.jar.Main --create --file $jar --manifest (Join-Path $agentRoot 'MANIFEST.MF') -C $classes . -C (Join-Path $agentRoot 'resources') . }
$cp="$gameJar;$libsDir\*;$jar;$tests"
RunStep 'build-contract' { & java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -cp $cp -d $tests (Join-Path $agentRoot 'tests\StrategyContractHarness.java') }
RunStep 'strategy-contract' { & java -cp $cp io.rwagent.client.StrategyContractHarness }
$env:RW_SPECIALIST_LIFECYCLE_EVIDENCE_DIR=Join-Path $logDir 'specialist-cases'
RunStep 'specialist-http' { & python (Join-Path $agentRoot 'tests\test_specialist_lifecycle.py') $jar }
RunStep 'funding-http' { & python (Join-Path $agentRoot 'tests\test_strategy_funding.py') $jar }
Write-Output 'Targeted validation completed.'
