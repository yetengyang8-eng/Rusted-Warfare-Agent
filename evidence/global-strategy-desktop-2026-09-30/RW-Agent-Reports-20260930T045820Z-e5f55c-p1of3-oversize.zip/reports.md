# 铁锈战争 Agent 离线报告汇总

结果由事件核对。INVALID 表示报告不完整或计数异常，即使原始 outcome 为 PASS 也不计入通过。

| 报告 | 版本 | 任务 | 判定 | 现实秒数 | 指令 | 观察 | 新矿 | 新厂 | 新坦克 | 建矿时完成坦克 |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| battle-1790743783098-ae01b65e.jsonl | 0.07-alpha1 | battle | PARTIAL | 480.47 | 648 | 844 | 13 | 3 | 0 | 0 |
| development-1790743770680-5e51fd16.jsonl | 0.07-alpha1 | development | PASS | 12.4 | 7 | 27 | 1 | 0 | 6 | 2 |
| economy-1790743761630-ec51c708.jsonl | 0.07-alpha1 | economy | PASS | 8.733 | 2 | 20 | 0 | 1 | 1 | 0 |

现实耗时从首个有效事件到最后一个有效事件计算，不是游戏内时间。建矿出兵重叠仅指日志观察区间：同一矿的 extractor_started 到 extractor_completed 之间出现 tank_completed；不等于性能或胜率证明。

| 对战报告 | 原生结算 | 对战游戏秒数 | 新观察战斗单位 | 己方损失 | 已确认进攻指令 | 工厂升级 |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| battle-1790743783098-ae01b65e.jsonl | ONGOING | 2402.32 | 139 | 82 | 227 | 4 |

对战 PASS 只表示已观察到原生结算。VICTORY 才是获胜；DEFEAT 是完整败局；PARTIAL 是仍在进行的限时样本。

## battle-1790743783098-ae01b65e.jsonl

**阶段** battle；**扩张** —

Game-time budget reached without native result

原始 summary

```json
{
  "outcome": "PARTIAL",
  "reason": "Game-time budget reached without native result",
  "phase": "battle",
  "matchOutcome": "ONGOING",
  "commands": 648,
  "observations": 844,
  "ownLosses": 82,
  "newCombatUnits": 139,
  "attackOrders": 242,
  "attackOrdersConfirmed": 227,
  "retreatOrders": 17,
  "upgradesCompleted": 4,
  "completedMines": 13,
  "newMines": 13,
  "mineTarget": 3,
  "minesBeyondFloor": 11,
  "expansionRefusals": 111,
  "expansionBlocked": 130,
  "completedFactories": 3,
  "newFactories": 3,
  "landFactoryTarget": 4,
  "factoryBlocks": 0,
  "builderTarget": 1,
  "builderRecoveries": 1,
  "builderOrders": 1,
  "battleGameTimeMs": 2402320,
  "gameSecondsPerWallSecond": 5.0,
  "noProgressWindowMs": 20000,
  "noProgressCooldownMs": 30000,
  "targetNoProgressTriggers": 0,
  "targetRetries": 0,
  "targetSuppressionsStarted": 2,
  "targetSuppressionsReleased": 0,
  "targetSuppressedSelections": 34,
  "targetSuppressionsAtEnd": 2,
  "targetSwitches": 140,
  "effectiveDecisionIntervalGameMs": 2940,
  "noProgressAttentionGapMs": 8820,
  "maxObservedGameTimeJump": 3610,
  "observationCount": 844,
  "spendTotal": 172150,
  "spendByCategory": {
    "FACTORY_UPGRADE": {
      "orders": 4,
      "cost": 8000
    },
    "NEW_MINE": {
      "orders": 12,
      "cost": 8400
    },
    "UNIT_PRODUCTION": {
      "orders": 136,
      "cost": 99350
    },
    "NEW_FACTORY": {
      "orders": 3,
      "cost": 2100
    },
    "STRATEGIC_CAPABILITY": {
      "orders": 9,
      "cost": 13500
    },
    "STRATEGIC_CONSTRUCTION": {
      "orders": 30,
      "cost": 22100
    },
    "MINE_UPGRADE": {
      "orders": 13,
      "cost": 18200
    },
    "BUILDER_RECOVERY": {
      "orders": 1,
      "cost": 500
    }
  },
  "measuredIncomePerGameSecond": 156.33,
  "investmentIntentions": 18,
  "investmentCompletions": 5,
  "investmentCancellations": 13,
  "investmentReserveAtEnd": 0,
  "investmentPendingAtEnd": false,
  "finalUrgency": "CONTESTED",
  "reconEnabled": true,
  "reconTasksCreated": 51,
  "reconOrdersQueued": 65,
  "reconOrdersObserved": 22,
  "reconMovesCompletedBetweenSamples": 43,
  "frontierTasksSatisfiedByTeamVision": 34,
  "reconResolvedAfterObservedMove": 5,
  "reconReacquired": 5,
  "reconSitesCleared": 2,
  "reconBlocked": 0,
  "reconTaskPendingAtEnd": true,
  "reconFrontierEnabled": true,
  "frontierTasksCreated": 43,
  "frontierTasksRefreshed": 1,
  "frontierTasksAdvanced": 2,
  "frontierTasksBlocked": 5,
  "frontierTasksPreempted": 1,
  "expendableTransfers": 2,
  "expendableScoutsAtEnd": 0,
  "factoryTargetIncreases": 2,
  "factoryTargetIncreaseBlocks": 2,
  "landFactoryTargetAtEnd": 4,
  "factoryTargetCommittedAtEnd": false,
  "landFactoryTargetMax": 5,
  "factorySaturationPct": 0.0,
  "factorySaturationMinPct": 80,
  "economyBaseIncome": 26.9,
  "economyIncomePerMine": 12.07,
  "economyModelSource": "MEASURED_4_MATCHES_2_SPEEDS_T1_R2_0.999_T2_T3_ESTIMATED_FROM_FROZEN_GENERATION_RATIOS",
  "minesReadyAtEnd": 16,
  "productionConsumptionPerGameSecond": 0.0,
  "sustainableSurplusPerGameSecond": 256.2,
  "strategy": {
    "enabled": true,
    "armyTarget": 92,
    "activeTarget": 80,
    "reserveTarget": 12,
    "hardSafetyCap": 128,
    "builderTarget": 2,
    "capabilityNeedsAtEnd": 2,
    "needsResolvedByLegalEvidence": 0,
    "investmentOrders": 52,
    "mineUpgradesObserved": 13,
    "constructionCompletionsObserved": 30
  }
}
```

## development-1790743770680-5e51fd16.jsonl

**阶段** tank_observe；**扩张** LIMIT_REACHED

Tank target completed; mines 1/1; expansion LIMIT_REACHED; all task units alive

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "Tank target completed; mines 1/1; expansion LIMIT_REACHED; all task units alive",
  "phase": "tank_observe",
  "commands": 7,
  "observations": 27,
  "completedMines": 1,
  "completedTanks": 6,
  "expansionStatus": "LIMIT_REACHED",
  "scoutMoves": 0,
  "scoutArrivals": 0,
  "scoutBlocked": 0,
  "scoutedMines": 0,
  "scoutRetreats": 0,
  "escortsAssigned": 0,
  "escortsConfirmed": 0,
  "newlyExploredTiles": 0
}
```

## economy-1790743761630-ec51c708.jsonl

**阶段** tank_1_produce；**扩张** —

New landFactory completed; its queue was observed active then empty; one new own tank appeared nearby

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "New landFactory completed; its queue was observed active then empty; one new own tank appeared nearby",
  "phase": "tank_1_produce",
  "commands": 2,
  "observations": 20,
  "completedBuildings": 1,
  "completedTanks": 1
}
```
