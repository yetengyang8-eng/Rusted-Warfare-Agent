# 铁锈战争 Agent 离线报告汇总

结果由事件核对。INVALID 表示报告不完整或计数异常，即使原始 outcome 为 PASS 也不计入通过。

| 报告 | 版本 | 任务 | 判定 | 现实秒数 | 指令 | 观察 | 新矿 | 新厂 | 新坦克 | 建矿时完成坦克 |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| battle-1790741949748-c01f222f.jsonl | 0.07-alpha1 | battle | PARTIAL | 480.463 | 703 | 882 | 11 | 2 | 0 | 0 |
| development-1790741937274-7d1c4895.jsonl | 0.07-alpha1 | development | PASS | 12.456 | 7 | 27 | 1 | 0 | 6 | 2 |
| economy-1790741927149-0bc234be.jsonl | 0.07-alpha1 | economy | PASS | 9.8 | 2 | 22 | 0 | 1 | 1 | 0 |

现实耗时从首个有效事件到最后一个有效事件计算，不是游戏内时间。建矿出兵重叠仅指日志观察区间：同一矿的 extractor_started 到 extractor_completed 之间出现 tank_completed；不等于性能或胜率证明。

| 对战报告 | 原生结算 | 对战游戏秒数 | 新观察战斗单位 | 己方损失 | 已确认进攻指令 | 工厂升级 |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| battle-1790741949748-c01f222f.jsonl | ONGOING | 2402.295 | 127 | 64 | 264 | 4 |

对战 PASS 只表示已观察到原生结算。VICTORY 才是获胜；DEFEAT 是完整败局；PARTIAL 是仍在进行的限时样本。

## battle-1790741949748-c01f222f.jsonl

**阶段** battle；**扩张** —

Game-time budget reached without native result

原始 summary

```json
{
  "outcome": "PARTIAL",
  "reason": "Game-time budget reached without native result",
  "phase": "battle",
  "matchOutcome": "ONGOING",
  "commands": 703,
  "observations": 882,
  "ownLosses": 64,
  "newCombatUnits": 127,
  "attackOrders": 289,
  "attackOrdersConfirmed": 264,
  "retreatOrders": 21,
  "upgradesCompleted": 4,
  "completedMines": 11,
  "newMines": 11,
  "mineTarget": 3,
  "minesBeyondFloor": 9,
  "expansionRefusals": 148,
  "expansionBlocked": 156,
  "completedFactories": 2,
  "newFactories": 2,
  "landFactoryTarget": 4,
  "factoryBlocks": 0,
  "builderTarget": 1,
  "builderRecoveries": 0,
  "builderOrders": 0,
  "battleGameTimeMs": 2402295,
  "gameSecondsPerWallSecond": 5.0,
  "noProgressWindowMs": 20000,
  "noProgressCooldownMs": 30000,
  "targetNoProgressTriggers": 0,
  "targetRetries": 0,
  "targetSuppressionsStarted": 13,
  "targetSuppressionsReleased": 0,
  "targetSuppressedSelections": 2173,
  "targetSuppressionsAtEnd": 13,
  "targetSwitches": 101,
  "effectiveDecisionIntervalGameMs": 2920,
  "noProgressAttentionGapMs": 8760,
  "maxObservedGameTimeJump": 3055,
  "observationCount": 882,
  "spendTotal": 151350,
  "spendByCategory": {
    "FACTORY_UPGRADE": {
      "orders": 4,
      "cost": 8000
    },
    "UNIT_PRODUCTION": {
      "orders": 123,
      "cost": 85350
    },
    "NEW_MINE": {
      "orders": 9,
      "cost": 6300
    },
    "NEW_FACTORY": {
      "orders": 2,
      "cost": 1400
    },
    "STRATEGIC_CAPABILITY": {
      "orders": 7,
      "cost": 15500
    },
    "STRATEGIC_CONSTRUCTION": {
      "orders": 18,
      "cost": 18000
    },
    "MINE_UPGRADE": {
      "orders": 12,
      "cost": 16800
    }
  },
  "measuredIncomePerGameSecond": 164.64,
  "investmentIntentions": 15,
  "investmentCompletions": 2,
  "investmentCancellations": 13,
  "investmentReserveAtEnd": 0,
  "investmentPendingAtEnd": false,
  "finalUrgency": "CONTESTED",
  "reconEnabled": true,
  "reconTasksCreated": 94,
  "reconOrdersQueued": 123,
  "reconOrdersObserved": 1,
  "reconMovesCompletedBetweenSamples": 122,
  "frontierTasksSatisfiedByTeamVision": 75,
  "reconResolvedAfterObservedMove": 1,
  "reconReacquired": 2,
  "reconSitesCleared": 0,
  "reconBlocked": 0,
  "reconTaskPendingAtEnd": false,
  "reconFrontierEnabled": true,
  "frontierTasksCreated": 92,
  "frontierTasksRefreshed": 0,
  "frontierTasksAdvanced": 9,
  "frontierTasksBlocked": 5,
  "frontierTasksPreempted": 3,
  "expendableTransfers": 4,
  "expendableScoutsAtEnd": 1,
  "factoryTargetIncreases": 2,
  "factoryTargetIncreaseBlocks": 3,
  "landFactoryTargetAtEnd": 4,
  "factoryTargetCommittedAtEnd": false,
  "landFactoryTargetMax": 5,
  "factorySaturationPct": 6.87,
  "factorySaturationMinPct": 80,
  "economyBaseIncome": 26.9,
  "economyIncomePerMine": 12.07,
  "economyModelSource": "MEASURED_4_MATCHES_2_SPEEDS_T1_R2_0.999_T2_T3_ESTIMATED_FROM_FROZEN_GENERATION_RATIOS",
  "minesReadyAtEnd": 11,
  "productionConsumptionPerGameSecond": 26.7,
  "sustainableSurplusPerGameSecond": 175.2,
  "strategy": {
    "enabled": true,
    "armyTarget": 78,
    "activeTarget": 66,
    "reserveTarget": 12,
    "hardSafetyCap": 128,
    "builderTarget": 1,
    "capabilityNeedsAtEnd": 13,
    "needsResolvedByLegalEvidence": 1,
    "investmentOrders": 37,
    "mineUpgradesObserved": 12,
    "constructionCompletionsObserved": 17
  }
}
```

## development-1790741937274-7d1c4895.jsonl

**阶段** tank_observe；**扩张** LIMIT_REACHED

Tank target completed; mines 1/1; expansion LIMIT_REACHED; all task units alive

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "Tank target completed; mines 1/1; expansion LIMIT_REACHED; all task units alive",
  "phase": "tank_observe",
  "commands": 7,
  "observations": 27,
  "completedMines": 1,
  "completedTanks": 6,
  "expansionStatus": "LIMIT_REACHED",
  "scoutMoves": 0,
  "scoutArrivals": 0,
  "scoutBlocked": 0,
  "scoutedMines": 0,
  "scoutRetreats": 0,
  "escortsAssigned": 0,
  "escortsConfirmed": 0,
  "newlyExploredTiles": 0
}
```

## economy-1790741927149-0bc234be.jsonl

**阶段** tank_1_produce；**扩张** —

New landFactory completed; its queue was observed active then empty; one new own tank appeared nearby

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "New landFactory completed; its queue was observed active then empty; one new own tank appeared nearby",
  "phase": "tank_1_produce",
  "commands": 2,
  "observations": 22,
  "completedBuildings": 1,
  "completedTanks": 1
}
```
