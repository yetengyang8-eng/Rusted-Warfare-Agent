# 铁锈战争 Agent 离线报告汇总

结果由事件核对。INVALID 表示报告不完整或计数异常，即使原始 outcome 为 PASS 也不计入通过。

| 报告 | 版本 | 任务 | 判定 | 现实秒数 | 指令 | 观察 | 新矿 | 新厂 | 新坦克 | 建矿时完成坦克 |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| battle-1790742800972-4064cebd.jsonl | 0.07-alpha1 | battle | PARTIAL | 480.377 | 631 | 867 | 4 | 1 | 0 | 0 |
| development-1790742788591-990b02bb.jsonl | 0.07-alpha1 | development | PASS | 12.363 | 7 | 27 | 1 | 0 | 6 | 2 |
| economy-1790742779539-61447a69.jsonl | 0.07-alpha1 | economy | PASS | 8.735 | 2 | 20 | 0 | 1 | 1 | 0 |

现实耗时从首个有效事件到最后一个有效事件计算，不是游戏内时间。建矿出兵重叠仅指日志观察区间：同一矿的 extractor_started 到 extractor_completed 之间出现 tank_completed；不等于性能或胜率证明。

| 对战报告 | 原生结算 | 对战游戏秒数 | 新观察战斗单位 | 己方损失 | 已确认进攻指令 | 工厂升级 |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| battle-1790742800972-4064cebd.jsonl | ONGOING | 2401.865 | 237 | 243 | 240 | 2 |

对战 PASS 只表示已观察到原生结算。VICTORY 才是获胜；DEFEAT 是完整败局；PARTIAL 是仍在进行的限时样本。

## battle-1790742800972-4064cebd.jsonl

**阶段** battle；**扩张** —

Game-time budget reached without native result

原始 summary

```json
{
  "outcome": "PARTIAL",
  "reason": "Game-time budget reached without native result",
  "phase": "battle",
  "matchOutcome": "ONGOING",
  "commands": 631,
  "observations": 867,
  "ownLosses": 243,
  "newCombatUnits": 237,
  "attackOrders": 241,
  "attackOrdersConfirmed": 240,
  "retreatOrders": 66,
  "upgradesCompleted": 2,
  "completedMines": 4,
  "newMines": 4,
  "mineTarget": 3,
  "minesBeyondFloor": 0,
  "expansionRefusals": 111,
  "expansionBlocked": 145,
  "completedFactories": 1,
  "newFactories": 1,
  "landFactoryTarget": 2,
  "factoryBlocks": 0,
  "builderTarget": 1,
  "builderRecoveries": 3,
  "builderOrders": 3,
  "battleGameTimeMs": 2401865,
  "gameSecondsPerWallSecond": 5.0,
  "noProgressWindowMs": 20000,
  "noProgressCooldownMs": 30000,
  "targetNoProgressTriggers": 0,
  "targetRetries": 0,
  "targetSuppressionsStarted": 12,
  "targetSuppressionsReleased": 3,
  "targetSuppressedSelections": 68,
  "targetSuppressionsAtEnd": 9,
  "targetSwitches": 184,
  "effectiveDecisionIntervalGameMs": 2825,
  "noProgressAttentionGapMs": 8475,
  "maxObservedGameTimeJump": 3040,
  "observationCount": 867,
  "spendTotal": 147100,
  "spendByCategory": {
    "FACTORY_UPGRADE": {
      "orders": 2,
      "cost": 4000
    },
    "NEW_MINE": {
      "orders": 5,
      "cost": 3500
    },
    "UNIT_PRODUCTION": {
      "orders": 237,
      "cost": 137400
    },
    "NEW_FACTORY": {
      "orders": 1,
      "cost": 700
    },
    "BUILDER_RECOVERY": {
      "orders": 3,
      "cost": 1500
    }
  },
  "measuredIncomePerGameSecond": 60.33,
  "investmentIntentions": 0,
  "investmentCompletions": 0,
  "investmentCancellations": 0,
  "investmentReserveAtEnd": 0,
  "investmentPendingAtEnd": false,
  "finalUrgency": "CONTESTED",
  "reconEnabled": true,
  "reconTasksCreated": 23,
  "reconOrdersQueued": 32,
  "reconOrdersObserved": 24,
  "reconMovesCompletedBetweenSamples": 8,
  "frontierTasksSatisfiedByTeamVision": 0,
  "reconResolvedAfterObservedMove": 8,
  "reconReacquired": 17,
  "reconSitesCleared": 0,
  "reconBlocked": 2,
  "reconTaskPendingAtEnd": true,
  "reconFrontierEnabled": true,
  "frontierTasksCreated": 3,
  "frontierTasksRefreshed": 0,
  "frontierTasksAdvanced": 0,
  "frontierTasksBlocked": 1,
  "frontierTasksPreempted": 2,
  "expendableTransfers": 2,
  "expendableScoutsAtEnd": 0,
  "factoryTargetIncreases": 0,
  "factoryTargetIncreaseBlocks": 1,
  "landFactoryTargetAtEnd": 2,
  "factoryTargetCommittedAtEnd": false,
  "landFactoryTargetMax": 5,
  "factorySaturationPct": 41.38,
  "factorySaturationMinPct": 80,
  "economyBaseIncome": 26.9,
  "economyIncomePerMine": 12.07,
  "economyModelSource": "MEASURED_4_MATCHES_2_SPEEDS_T1_R2_0.999_T2_T3_ESTIMATED_FROM_FROZEN_GENERATION_RATIOS",
  "minesReadyAtEnd": 2,
  "productionConsumptionPerGameSecond": 38.3,
  "sustainableSurplusPerGameSecond": 12.7,
  "strategy": {
    "enabled": true,
    "armyTarget": 35,
    "activeTarget": 27,
    "reserveTarget": 8,
    "hardSafetyCap": 128,
    "builderTarget": 1,
    "capabilityNeedsAtEnd": 6,
    "needsResolvedByLegalEvidence": 0,
    "investmentOrders": 0,
    "mineUpgradesObserved": 0,
    "constructionCompletionsObserved": 0
  }
}
```

## development-1790742788591-990b02bb.jsonl

**阶段** tank_observe；**扩张** LIMIT_REACHED

Tank target completed; mines 1/1; expansion LIMIT_REACHED; all task units alive

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "Tank target completed; mines 1/1; expansion LIMIT_REACHED; all task units alive",
  "phase": "tank_observe",
  "commands": 7,
  "observations": 27,
  "completedMines": 1,
  "completedTanks": 6,
  "expansionStatus": "LIMIT_REACHED",
  "scoutMoves": 0,
  "scoutArrivals": 0,
  "scoutBlocked": 0,
  "scoutedMines": 0,
  "scoutRetreats": 0,
  "escortsAssigned": 0,
  "escortsConfirmed": 0,
  "newlyExploredTiles": 0
}
```

## economy-1790742779539-61447a69.jsonl

**阶段** tank_1_produce；**扩张** —

New landFactory completed; its queue was observed active then empty; one new own tank appeared nearby

原始 summary

```json
{
  "outcome": "PASS",
  "reason": "New landFactory completed; its queue was observed active then empty; one new own tank appeared nearby",
  "phase": "tank_1_produce",
  "commands": 2,
  "observations": 20,
  "completedBuildings": 1,
  "completedTanks": 1
}
```
